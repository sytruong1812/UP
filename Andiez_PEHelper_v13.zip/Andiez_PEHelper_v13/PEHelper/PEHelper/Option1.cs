﻿using System;
using System.Text; 
using System.Runtime.InteropServices;
using PEHelper.Pe; 

namespace PEHelper
{
    public class Option1
    {
        public static bool UpdateConfig(string pePath, string secName, DataConfig new_config)
        {
            PeEditor pe = new PeEditor(pePath);
            byte[] pConfigData = pe.ExtractSectionWithName(secName);
            // Ensure pConfigData is large enough for DataConfig structure
            if (pConfigData == null || (pConfigData.Length < Marshal.SizeOf(typeof(DataConfig))))
            {
                return false;
            }
            // Copy data into DataConfig using struct marshalling
            DataConfig old_config = Helper.ByteArrayToStruct<DataConfig>(pConfigData);

            Console.WriteLine("----------- [DATA CONFIG] -------------");
            Console.WriteLine($"App ID:             0x{old_config.app_id:X}");
            Console.WriteLine($"User ID:            0x{old_config.user_id:X}");
            Console.WriteLine($"Time Zone:          0x{old_config.time_zone:X}");
            Console.WriteLine($"Server Address:     {Helper.ConvertByteArrayToString(old_config.server_address)}");
            Console.WriteLine($"Email:              {Helper.ConvertByteArrayToString(old_config.email)}");
            Console.OutputEncoding = Encoding.Unicode;
            Console.WriteLine($"Full Name:          {Helper.ConvertByteArrayToWString(old_config.full_name)}");
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine($"IV Decrypt Data:    {Helper.ConvertByteArrayToString(old_config.iv_data)}");
            Console.WriteLine($"Key Decrypt Data:   {Helper.ConvertByteArrayToString(old_config.key_data)}");
            Console.WriteLine($"Data Encrypted:     {Helper.ConvertByteArrayToString(old_config.data_encrypted)}");

            // Convert the updated DataConfig back to byte array
            byte[] newData = Helper.StructToByteArray(new_config);
            Array.Clear(pConfigData, 0, pConfigData.Length);            // Zero out old data
            Array.Copy(newData, 0, pConfigData, 0, newData.Length);     // Copy the new data into pConfigData

            if(!pe.EmbedDataToSection(secName, newData))
            {
                Console.WriteLine("Embedd data into {0} section failed!", secName);
                return false;
            }
            if (!pe.Save(pePath))
            {
                return false;
            }

            return true;
        }
    }
}
