﻿using System;
using System.Runtime.InteropServices;
using System.Text;


namespace PEHelper
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public struct DataConfig
    {
        public Int32 app_id;
        public UInt32 user_id;
        public UInt64 time_zone;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        public byte[] server_address;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
        public byte[] email;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
        public byte[] full_name;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
        public byte[] iv_data;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        public byte[] key_data;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1024)]
        public byte[] data_encrypted;
    }
    public class Helper
    {
        static public T ByteArrayToStruct<T>(byte[] byteArray)
        {
            IntPtr ptr = Marshal.AllocHGlobal(byteArray.Length);
            try
            {
                Marshal.Copy(byteArray, 0, ptr, byteArray.Length);
                return (T)Marshal.PtrToStructure(ptr, typeof(T));
            }
            finally
            {
                Marshal.FreeHGlobal(ptr);
            }
        }
        static public byte[] StructToByteArray(DataConfig obj)
        {
            int size = Marshal.SizeOf(obj);
            byte[] arr = new byte[size];
            IntPtr ptr = Marshal.AllocHGlobal(size);
            try
            {
                Marshal.StructureToPtr(obj, ptr, false);
                Marshal.Copy(ptr, arr, 0, size);
            }
            finally
            {
                Marshal.FreeHGlobal(ptr);
            }
            return arr;
        }
        static public string ConvertByteArrayToString(byte[] byteArray)
        {
            if (byteArray == null || byteArray.Length == 0)
            {
                return string.Empty;
            }
            int nullIndex = Array.IndexOf(byteArray, (byte)0);
            if (nullIndex == -1)
            {
                return Encoding.ASCII.GetString(byteArray);
            }
            else
            {
                return Encoding.ASCII.GetString(byteArray, 0, nullIndex);
            }
        }
        static public string ConvertByteArrayToWString(byte[] byteArray)
        {
            if (byteArray == null || byteArray.Length == 0)
            {
                return string.Empty;
            }
            // Find the index of the first null terminator (0x00 0x00)
            int nullIndex = -1;
            for (int i = 0; i < byteArray.Length - 1; i += 2) // Increment by 2 to check for UTF-16
            {
                if (byteArray[i] == 0 && byteArray[i + 1] == 0)
                {
                    nullIndex = i;
                    break;
                }
            }
            if (nullIndex == -1)
            {
                return Encoding.Unicode.GetString(byteArray);
            }
            else
            {
                return Encoding.Unicode.GetString(byteArray, 0, nullIndex);
            }
        }
    }
}
