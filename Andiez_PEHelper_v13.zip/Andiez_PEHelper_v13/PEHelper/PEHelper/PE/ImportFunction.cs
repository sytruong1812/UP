﻿using System;
using PEHelper.Pe;

namespace PEHelper.PE
{
    public class ImportFunction
    {
        public ImportFunction(string name, UInt16 hint, uint iatOffset, UInt64 originalThunk, UInt64 thunk)
        {
            Name = name;
            Hint = hint;
            IATOffset = iatOffset;
            OriginalThunk = originalThunk;
            Thunk = thunk;
        }
        public string Name { get; }
        public UInt16 Hint { get; }
        public uint IATOffset { get; }
        public UInt64 OriginalThunk { get; }
        public UInt64 Thunk { get; }

    }
}
