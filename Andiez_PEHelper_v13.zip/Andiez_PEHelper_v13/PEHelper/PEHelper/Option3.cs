﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using PEHelper.Pe;
using System.Runtime.InteropServices;

namespace PEHelper
{
    public class Option3
    {
        const int SIGN_SIZE = 8;

        private static void CopyData(ref byte[] dataConfig, ref int offset, byte[] data)
        {
            Array.Copy(BitConverter.GetBytes(data.Length), 0, dataConfig, offset, sizeof(UInt32));
            offset += sizeof(UInt32);
            Array.Copy(data, 0, dataConfig, offset, data.Length);
            offset += data.Length;
        }

        public static bool UpdateConfig(string pePath, string sign, DataConfig new_config)
        {
            PeEditor pe = new PeEditor(pePath);
            byte[] sign_bytes = Encoding.ASCII.GetBytes(sign);

            foreach (var section in pe.SectionHeaders)
            {
                byte[] buffer = pe.ExtractSectionWithName(section.Name);
                for (int i = 0; i < buffer.Length; i++)
                {
                    if (buffer.Skip(i).Take(sign_bytes.Length).SequenceEqual(sign_bytes))
                    {
                        UInt32 array_size = BitConverter.ToUInt32(buffer, i + SIGN_SIZE);
                        byte[] data_config = new byte[array_size];
                        int current_offset = 0;

                        // Update Sign
                        byte[] sign_update = Encoding.ASCII.GetBytes("SIGN:NEW");
                        Array.Copy(sign_update, 0, data_config, current_offset, sign_update.Length);
                        current_offset += sign_update.Length;
                        Array.Copy(BitConverter.GetBytes(array_size), 0, data_config, current_offset, sizeof(UInt32));
                        current_offset += sizeof(UInt32);

                        // Copy Data Config Fields
                        CopyData(ref data_config, ref current_offset, BitConverter.GetBytes(new_config.app_id));
                        CopyData(ref data_config, ref current_offset, BitConverter.GetBytes(new_config.user_id));
                        CopyData(ref data_config, ref current_offset, BitConverter.GetBytes(new_config.time_zone));
                        CopyData(ref data_config, ref current_offset, new_config.server_address);
                        CopyData(ref data_config, ref current_offset, new_config.email);
                        CopyData(ref data_config, ref current_offset, new_config.full_name);
                        CopyData(ref data_config, ref current_offset, new_config.iv_data);
                        CopyData(ref data_config, ref current_offset, new_config.key_data);
                        CopyData(ref data_config, ref current_offset, new_config.data_encrypted);

                        // Replace data and save
                        if (!pe.ReplaceDataToSectionAt(section.Name, i, data_config))
                        {
                            Console.WriteLine("Embedding data into {0} section failed!", section.Name);
                            return false;
                        }
                        if (!pe.Save(pePath))
                        {
                            return false;
                        }
                        return true;
                    }
                }
            }
            return false;
        }
    }
}
