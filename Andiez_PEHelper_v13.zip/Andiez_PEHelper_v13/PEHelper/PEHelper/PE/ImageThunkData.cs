﻿using System;
using PEHelper.Pe;

namespace PEHelper.PE
{
    public class ImageThunkData : SafeStruct
    {
        private readonly bool is32Bits;
        private enum Offset : int
        {
            ForwarderString = 0,        //0
            Function = 1,               //4
            Ordinal = 2,                //8
            AddressOfData = 3,          //12
            ThunkDataSize = 4,
        }
        public ImageThunkData(byte[] buffer, int offset, bool is32Bit) : base(buffer, offset)
        {
            is32Bits = is32Bit;

        }
        public UInt64 AddressOfData
        {
            get
            {
                if (is32Bits)
                {
                    return ToUInt32(0);
                }

                return ToUInt64(0);
            }
            set
            {
                if (is32Bits)
                {
                    SetUInt32((uint)value, 0);
                }
                else
                {
                    SetUInt64(value, 0);
                }
            }
        }
        public UInt64 Ordinal
        {
            get => AddressOfData;
            set => AddressOfData = value;
        }
        public UInt64 ForwarderString
        {
            get => AddressOfData;
            set => AddressOfData = value;
        }
        public UInt64 Function
        {
            get => AddressOfData;
            set => AddressOfData = value;
        }
        public override int RawSize
        {
            get => sizeof(UInt32);
        }
    }
}
