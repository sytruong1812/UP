﻿#include <vector>
#include <iostream>
#include <windows.h>
#include <algorithm>
#include <mbstring.h>

#include "aes.h"
#include "pkcs7.h"
#include "show_config.h"

#define OPTION_4 1

#ifdef OPTION_1
#include "option1.h"

// Create an initialized instance of the struct in the new section
__declspec(allocate(".stub")) ConfigData config = 
{
	0xEEEEEE,
	0xCCCCCCCC,
	0xAAAAAAAAAAAA,
	"192.168.1.9",
	"abc@gmail.com",
	L"Nguyễn Sỹ Trường",
	{
		0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0,
		0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0
	},
	{
		0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0,
		0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0,
		0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0,
		0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0
	},
	{
		0xA3, 0xB7, 0x4C, 0x96, 0x5A, 0xBC, 0xD7, 0x0D,
		0xC8, 0x23, 0xEE, 0x98, 0xF3, 0xE2, 0xAB, 0x9E
	}
};

#endif //END_OPTION_1
#ifdef OPTION_2
#include "option2.h"

ConfigData config 
{
	0xEEEEEE,
	0xCCCCCCCC,
	0xAAAAAAAAAAAA,
	"192.168.1.9",
	"abc@gmail.com",
	L"Nguyễn Sỹ Trường",
	{
		0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0,
		0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0
	},
	{
		0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0,
		0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0,
		0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0,
		0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0
	},
	{
		0xA3, 0xB7, 0x4C, 0x96, 0x5A, 0xBC, 0xD7, 0x0D,
		0xC8, 0x23, 0xEE, 0x98, 0xF3, 0xE2, 0xAB, 0x9E
	}
};

#endif //END_OPTION_2
#ifdef OPTION_3
#include "option3.h"

ConfigData* parseArray() {
	if (!ConfigParser::instance().parseData())
	{
		std::cout << "Error: Failed to parse configuration data." << std::endl;
		return NULL;
	}
	return ConfigParser::instance().getConfig();
}

#endif //END_OPTION_3
#ifdef OPTION_4
#include "option4.h"

void UsingConfig()
{
	int app = app_id;
	unsigned int user = user_id;
	unsigned long long time = time_zone;
	std::string address = server_address;
	std::string mail = email;
	std::wstring name = full_name;
	uint8_t* iv = iv_data;
	uint8_t* key = key_data;
	uint8_t* data = data_encrypted;
}

void UpdateConfig()
{
	app_id = 0;
	user_id = 0;
	time_zone = 0;
	memset(server_address, 0, sizeof(server_address));
	memset(email, 0, sizeof(email));
	memset(full_name, 0, sizeof(full_name));
	memset(iv_data, 0, sizeof(iv_data));
	memset(key_data, 0, sizeof(key_data));
	memset(data_encrypted, 0, sizeof(data_encrypted));
}

#endif //END_OPTION_4

int wmain()
{
#if OPTION_1
	std::wcout << L"##############[ SHOW_TYPE_1 ]############" << std::endl;
	ShowConfig(config.app_id,
		config.user_id,
		config.time_zone,
		config.email,
		config.server_address,
		config.full_name,
		config.iv_data,
		config.key_data,
		config.data_encrypted);
	std::wcout << L"##############[ SHOW_TYPE_2 ]############" << std::endl;
	ShowConfig1(&config.app_id,
		&config.user_id,
		&config.time_zone,
		config.email,
		config.server_address,
		config.full_name,
		config.iv_data,
		config.key_data,
		config.data_encrypted);
	std::wcout << L"##############[ SHOW_TYPE_3 ]############" << std::endl;
	ShowConfig2(config.app_id,
		config.user_id,
		config.time_zone,
		config.email,
		config.server_address,
		config.full_name,
		config.iv_data,
		config.key_data,
		config.data_encrypted);
#endif
#if OPTION_2
	std::wcout << L"##############[ BEFORE_UPDATE ]############" << std::endl;
	ShowConfig2(config.app_id,
		config.user_id,
		config.time_zone,
		config.email,
		config.server_address,
		config.full_name,
		config.iv_data,
		config.key_data,
		config.data_encrypted);
	std::wcout << L"##############[ AFTER_UPDATE ]############" << std::endl;
	if (!UpdateConfig(&config, ".stub"))
	{
		std::wcout << "Failed to update configuration data." << std::endl;
	}
	ShowConfig2(config.app_id,
		config.user_id,
		config.time_zone,
		config.email,
		config.server_address,
		config.full_name,
		config.iv_data,
		config.key_data,
		config.data_encrypted);
#endif
#if OPTION_3
	ConfigData* config = parseArray();
	ShowConfig1(&config->app_id,
		&config->user_id,
		&config->time_zone,
		config->email,
		config->server_address,
		config->full_name,
		config->iv_data,
		config->key_data,
		config->data_encrypted);
#endif
#if OPTION_4
	UsingConfig();
	UpdateConfig();
	ShowConfig2(app_id, user_id, time_zone, email, server_address, 
				full_name, iv_data, key_data, data_encrypted);
#endif
	return 0;
}



