﻿using System;

namespace PEHelper.Pe
{
    public class ExceptionRecord : SafeStruct
    {
        private enum Offset : int
        {
            BeginAddress = 0,
            EndAddress = BeginAddress + sizeof(UInt32),
            UnwindData = EndAddress + sizeof(UInt32),
            ExceptionRecordSize = UnwindData + sizeof(UInt32),
        }
        public UInt32 BeginAddress
        {
            get
            {
                return ToUInt32(Offset.BeginAddress);
            }
            set
            {
                SetUInt32(value, Offset.BeginAddress);
            }
        }
        public UInt32 EndAddress
        {
            get
            {
                return ToUInt32(Offset.EndAddress);
            }
            set
            {
                SetUInt32(value, Offset.EndAddress);
            }
        }
        public UInt32 UnwindData
        {
            get
            {
                return ToUInt32(Offset.UnwindData);
            }
            set
            {
                SetUInt32(value, Offset.UnwindData);
            }
        }
        public override int RawSize
        {
            get
            {
                return (int)Offset.ExceptionRecordSize;
            }
        }
        public bool IsEmpty
        {
            get
            {
                return BeginAddress == 0 && EndAddress == 0 && UnwindData == 0;
            }
        }
        public ExceptionRecord(Byte[] buffer, int offset = 0) : base(buffer, offset)
        {

        }
    }
}
