﻿#pragma once
#include <string>
#include <Windows.h>

/* BAD Function!
The app_id, user_id, time_zone parameters are passed by value,
the function will receive copies of the passed values.
*/
void ShowConfig(int app_id, 
    unsigned int user_id,
    unsigned long long time_zone,
    const char* email, 
    const char* server_address, 
    const wchar_t* full_name,
    const unsigned char* iv_data,
    const unsigned char* key_data,
    const unsigned char* data_encrypted);
 
void ShowConfig1(const int* app_id, 
    const unsigned int* user_id,
    const unsigned long long* time_zone,
    const char* email, 
    const char* server_address, 
    const wchar_t* full_name,
    const unsigned char* iv_data,
    const unsigned char* key_data,
    const unsigned char* data_encrypted);

void ShowConfig2(const int32_t& app_id,
    const uint32_t& user_id,
    const int64_t& time_zone,
    const std::string& email, 
    const std::string& server_address, 
    const std::wstring& full_name,
    const uint8_t* iv_data,
    const uint8_t* key_data,
    const uint8_t* data_encrypted);


