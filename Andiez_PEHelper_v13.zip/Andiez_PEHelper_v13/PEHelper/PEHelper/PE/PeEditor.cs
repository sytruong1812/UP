﻿using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Xml.Linq;

namespace PEHelper.Pe
{
    public enum DataDirectoryIndex : int
    {
        /// <summary>
        ///     Export directory.
        /// </summary>
        Export = 0,

        /// <summary>
        ///     Import directory.
        /// </summary>
        Import = 1,

        /// <summary>
        ///     Resource directory.
        /// </summary>
        Resource = 2,

        /// <summary>
        ///     Exception directory for x64.
        /// </summary>
        Exception = 3,

        /// <summary>
        ///     Security directory.
        /// </summary>
        Security = 4,

        /// <summary>
        ///     Relocation directory.
        /// </summary>
        BaseReloc = 5,

        /// <summary>
        ///     Debug directory.
        /// </summary>
        Debug = 6,

        /// <summary>
        ///     Copyright directory (useless).
        /// </summary>
        Copyright = 7,

        /// <summary>
        ///     Global Pointer directory. Only interesting for Itanium systems.
        /// </summary>
        Globalptr = 8,

        /// <summary>
        ///     Thread Local Storage directory.
        /// </summary>
        TLS = 9,

        /// <summary>
        ///     Load Config directory.
        /// </summary>
        LoadConfig = 0xA,

        /// <summary>
        ///     Bound Import directory. Precomputed import addresses
        ///     to speed up module loading.
        /// </summary>
        BoundImport = 0xB,

        /// <summary>
        ///     Import Address Table directory.
        /// </summary>
        IAT = 0xC,

        /// <summary>
        ///     Delayed Import directory. Imports which are loaded
        ///     with a delay for performance reasons.
        /// </summary>
        DelayImport = 0xD,

        /// <summary>
        ///     COM Descriptor directory. For the .Net Header
        /// </summary>
        COM_Descriptor = 0xE,

        /// <summary>
        ///     Reserved for future use.
        /// </summary>
        Reserved = 0xF
    }
    public enum ScnCharacteristicsType : uint
    {
        /// <summary>
        ///     Reserved.
        /// </summary>
        TypeNoPad = 0x00000008,

        /// <summary>
        ///     Section contains code.
        /// </summary>
        CntCode = 0x00000020,

        /// <summary>
        ///     Section contains initialized data.
        /// </summary>
        CntInitializedData = 0x00000040,

        /// <summary>
        ///     Section contains uninitialized data.
        /// </summary>
        CntUninitializedData = 0x00000080,

        /// <summary>
        ///     Reserved.
        /// </summary>
        LnkOther = 0x00000100,

        /// <summary>
        ///     Section contains comments or some  other type of information.
        /// </summary>
        LnkInfo = 0x00000200,

        /// <summary>
        ///     Section contents will not become part of image.
        /// </summary>
        LnkRemove = 0x00000800,

        /// <summary>
        ///     Section contents comdat.
        /// </summary>
        LnkComdat = 0x00001000,

        /// <summary>
        ///     Reset speculative exceptions handling bits in the TLB entries for this section.
        /// </summary>
        NoDeferSpecExc = 0x00004000,

        /// <summary>
        ///     Section content can be accessed relative to GP.
        /// </summary>
        Gprel = 0x00008000,

        /// <summary>
        ///     Unknown.
        /// </summary>
        MemFardata = 0x00008000,

        /// <summary>
        ///     Unknown.
        /// </summary>
        MemPurgeable = 0x00020000,

        /// <summary>
        ///     Unknown.
        /// </summary>
        Mem16Bit = 0x00020000,

        /// <summary>
        ///     Unknown.
        /// </summary>
        MemLocked = 0x00040000,

        /// <summary>
        ///     Unknown.
        /// </summary>
        MemPreload = 0x00080000,

        /// <summary>
        ///     Section alignment.
        /// </summary>
        Align1Bytes = 0x00100000,

        /// <summary>
        ///     Section alignment.
        /// </summary>
        Align2Bytes = 0x00200000,

        /// <summary>
        ///     Section alignment.
        /// </summary>
        Align4Bytes = 0x00300000,

        /// <summary>
        ///     Section alignment.
        /// </summary>
        Align8Bytes = 0x00400000,

        /// <summary>
        ///     Default alignment if no others are specified.
        /// </summary>
        Align16Bytes = 0x00500000,

        /// <summary>
        ///     Section alignment.
        /// </summary>
        Align32Bytes = 0x00600000,

        /// <summary>
        ///     Section alignment.
        /// </summary>
        Align64Bytes = 0x00700000,

        /// <summary>
        ///     Section alignment.
        /// </summary>
        Align128Bytes = 0x00800000,

        /// <summary>
        ///     Section alignment.
        /// </summary>
        Align256Bytes = 0x00900000,

        /// <summary>
        ///     Section alignment.
        /// </summary>
        Align512Bytes = 0x00A00000,

        /// <summary>
        ///     Section alignment.
        /// </summary>
        Align1024Bytes = 0x00B00000,

        /// <summary>
        ///     Section alignment.
        /// </summary>
        Align2048Bytes = 0x00C00000,

        /// <summary>
        ///     Section alignment.
        /// </summary>
        Align4096Bytes = 0x00D00000,

        /// <summary>
        ///     Section alignment.
        /// </summary>
        Align8192Bytes = 0x00E00000,

        /// <summary>
        ///     Alignment mask.
        /// </summary>
        AlignMask = 0x00F00000,

        /// <summary>
        ///     Section contains extended relocations.
        /// </summary>
        LnkNrelocOvfl = 0x01000000,

        /// <summary>
        ///     Section can be discarded.
        /// </summary>
        MemDiscardable = 0x02000000,

        /// <summary>
        ///     Section is not cache-able.
        /// </summary>
        MemNotCached = 0x04000000,

        /// <summary>
        ///     Section is not page-able.
        /// </summary>
        MemNotPaged = 0x08000000,

        /// <summary>
        ///     Section is shareable.
        /// </summary>
        MemShared = 0x10000000,

        /// <summary>
        ///     Section is executable.
        /// </summary>
        MemExecute = 0x20000000,

        /// <summary>
        ///     Section is readable.
        /// </summary>
        MemRead = 0x40000000,

        /// <summary>
        ///     Section is write-able.
        /// </summary>
        MemWrite = 0x80000000
    }
    public struct IMAGE_IMPORT_DESCRIPTOR
    {
        public UInt32 OriginalFirstThunk;
        public UInt32 TimeDateStamp;
        public UInt32 ForwarderChain;
        public UInt32 Name;
        public UInt32 FirstThunk;
    }
    public struct IMAGE_THUNK_DATA32
    {
        public UInt32 ForwarderString;
        public UInt32 Function;
        public UInt32 Ordinal;
        public UInt32 AddressOfData;
    }
    public struct IMAGE_THUNK_DATA64
    {
        public UInt64 ForwarderString;
        public UInt64 Function;
        public UInt64 Ordinal;
        public UInt64 AddressOfData;
    }
    
    public class PeEditor : SafeStruct
    {
        public DosHeader DosHeader { get; private set; }
        public FileHeader FileHeader { get; private set; }
        public OptionalHeader OptionalHeader { get; private set; }
        public SectionHeader[] SectionHeaders { get; private set; }
        public DebugDirectory DebugDirectory { get; private set; }

        private readonly DateTime Epoch = new DateTime(1970, 1, 1, 0, 0, 0);
        public DateTime TimeDateStamp
        {
            get
            {
                if ((int)FileHeader.TimeDateStamp == -1)
                {
                    return DateTime.MinValue;
                }
                TimeSpan elapsedTime = TimeSpan.FromSeconds(FileHeader.TimeDateStamp);
                return Epoch + elapsedTime;
            }
        }
        public override int RawSize
        {
            get
            {
                return 0;
            }
        }
        public Guid PdbSignature
        {
            get
            {
                if (DebugDirectory != null && DebugDirectory.DebugInfo != null)
                {
                    return DebugDirectory.DebugInfo.PdbSignature;
                }
                return Guid.Empty;
            }
        }
        public UInt32 Signature
        {
            get
            {
                return ToUInt32(DosHeader.Lfanew);
            }
        }
        public string PdbPath
        {
            get
            {
                if (DebugDirectory != null && DebugDirectory.DebugInfo != null)
                {
                    return DebugDirectory.DebugInfo.PdbPath;
                }
                return null;
            }
        }
        public bool Is32Bits
        {
            get
            {
                if (OptionalHeader == null)
                {
                    return false;
                }
                return OptionalHeader.Is86;
            }
        }
        public UInt32 PESize { get; set; }
        public PeEditor(Byte[] buffer, int offset = 0) : base(buffer.ToArray(), offset) { }
        public PeEditor(string path) : this(File.ReadAllBytes(path)) 
        {
            PESize = (UInt32)(new FileInfo(path).Length);
            Parser();
        }
        public bool IsSectionExist(string sectionName)
        {
            // Check if any section header matches the given section name
            return SectionHeaders.Any(s => s.Name.Equals(sectionName, StringComparison.OrdinalIgnoreCase));
        }
        public bool RemoveSection(string sectionName, bool removeContent = true)
        {
            var sectionToRemove = (SectionHeaders ?? throw new InvalidOperationException("ImageSectionHeaders must not be null.")).First(s => s.Name == sectionName);
            // Remove section from list of sections
            var newSections = SectionHeaders.Where(s => s.Name != sectionName).ToArray();

            if (removeContent)
            {
                // Reloc the physical address of all sections
                foreach (var s in newSections)
                {
                    if (s.PointerToRawData > sectionToRemove.PointerToRawData)
                    {
                        s.PointerToRawData -= sectionToRemove.SizeOfRawData;
                    }
                }
                // Remove section content
                RemoveRange(sectionToRemove.PointerToRawData, sectionToRemove.SizeOfRawData);
            }

            // Change number of sections in the file header
            FileHeader.NumberOfSections--;

            // Fix virtual size
            for (var i = 1; i < newSections.Length; i++)
            {
                if (newSections[i - 1].VirtualAddress < sectionToRemove.VirtualAddress)
                {
                    newSections[i - 1].VirtualSize = newSections[i].VirtualAddress - newSections[i - 1].VirtualAddress;
                }
            }

            // Replace old section headers with new section headers
            var sectionHeaderOffset = DosHeader.Lfanew + FileHeader.SizeOfOptionalHeader + 0x18;
            var sizeOfSection = 0x28;
            var newRawSections = new byte[newSections.Length * sizeOfSection];
            for (var i = 0; i < newSections.Length; i++)
            {
                Array.Copy(newSections[i].ToArray(), 0, newRawSections, i * sizeOfSection, sizeOfSection);
            }

            // Null the data directory entry if any available
            var de = OptionalHeader.DataDirectories.FirstOrDefault(d => d.Address == sectionToRemove.VirtualAddress && d.Size == sectionToRemove.VirtualSize);
            if (de != null) {
                de.Size = 0;
                de.Address = 0;
            }
            return true;
        }
        public bool AppendNewSection(string sectionName, uint virtualSize, uint characteristics)
        {
            if (DosHeader is null)
            {
                Console.WriteLine("DosHeader is NULL!");
                return false;
            }
            if (OptionalHeader is null)
            {
                Console.WriteLine("OptionalHeader is NULL!");
                return false;
            }
            if (FileHeader is null)
            {
                Console.WriteLine("FileHeader is NULL!");
                return false;
            }
            //Resize buffer 
            uint fSizeNew_ = Align((PESize + virtualSize), OptionalHeader.FileAlignment);
            if (Append(fSizeNew_) == false)
            {
                Console.WriteLine("Can't append new file size for embed data!");
                return false;
            }
            //Parser new
            if (!Parser())
            {
                Console.WriteLine("Reparsing buffer failed!");
                return false;
            }
            //Canulate offset for new SectionHeader
            ushort numberOfSections_ = FileHeader.NumberOfSections;
            var lastSectionHeader = SectionHeaders[numberOfSections_ - 1];
            var offset = (DosHeader.Lfanew + sizeof(UInt32)) + FileHeader.RawSize + OptionalHeader.RawSize + (lastSectionHeader.RawSize * numberOfSections_);

            //Resize SectionHeader array
            int oldSize = SectionHeaders.Length;
            int newSize = numberOfSections_ + 1;
            Type elementType = SectionHeaders.GetType().GetElementType();
            Array newArray = Array.CreateInstance(elementType, newSize);
            Int32 preserveLength = Math.Min(oldSize, newSize);
            if (preserveLength > 0) {
                Array.Copy(SectionHeaders, newArray, preserveLength);
            }
            SectionHeaders = (SectionHeader[])newArray;

            //Check name size
            if (sectionName.Length > 8)
            {
                Console.WriteLine("Section names cannot be longer than 8 bytes!");
                return false;
            }
            //New a Section
            try
            {
                var newSectionHeader = new SectionHeader(_buffer, offset)
                {
                    Name = sectionName,
                    VirtualSize = virtualSize,
                    VirtualAddress = Align(lastSectionHeader.VirtualAddress + lastSectionHeader.VirtualSize, OptionalHeader.SectionAlignment),
                    SizeOfRawData = Align(virtualSize, OptionalHeader.FileAlignment),
                    PointerToRawData = PESize,
                    PointerToRelocations = 0,
                    PointerToLinenumbers = 0,
                    NumberOfRelocations = 0,
                    NumberOfLinenumbers = 0,
                    Characteristics = characteristics,
                };
                //Add new Section to SectionHeader array
                SectionHeaders.SetValue(newSectionHeader, numberOfSections_);
                //Change number of sections of the FileHeader
                FileHeader.NumberOfSections = (ushort)(numberOfSections_ + 1);
                //Change size of Image of the OptionalHeader
                OptionalHeader.SizeOfImage = Align(OptionalHeader.SizeOfImage + virtualSize, OptionalHeader.SectionAlignment);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: {0}", ex.Message);
                return false;
            }
            return true;
        }
        public bool EmbedDataToSection(string sectionName, byte[] dataEmbed)
        {
            foreach (var section in SectionHeaders)
            {
                if (section.Name.Trim('\0') == sectionName)
                {
                    Array.Copy(dataEmbed, 0, _buffer, section.PointerToRawData, dataEmbed.Length);
                    if (!Parser())  //Reparsing -> Get _buffer with new format PE
                    {
                        Console.WriteLine("Reparsing buffer failed!");
                        return false;
                    }
                    return true;
                }
            }
            return false;
        }
        public bool ReplaceDataToSectionAt(string sectionName, int index, byte[] dataReplace)
        {
            if (string.IsNullOrEmpty(sectionName) || dataReplace == null || index < 0)
            {
                return false;
            }
            var section = SectionHeaders.FirstOrDefault(s => s.Name.Trim('\0') == sectionName.Trim('\0'));
            if (section == null)
            {
                return false;
            } 

            // Check bounds
            if (index + dataReplace.Length > section.SizeOfRawData)
            {
                return false;
            }
            try
            {
                Buffer.BlockCopy(dataReplace, 0, _buffer, (int)(section.PointerToRawData + index), dataReplace.Length);
                return Parser();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error replacing data: {ex.Message}");
                return false;
            }
        }
        public bool EmbedDataToSectionWithAes(string sectionName, byte[] dataEmbed, byte[] key, byte[] iv)
        {
            byte ks_value;
            switch (key.Length * 8)
            {
                case 128:
                    ks_value = 0x10;
                    break;
                case 192:
                    ks_value = 0x18;
                    break;
                case 256:
                    ks_value = 0x20;
                    break;
                default:
                    Console.WriteLine("Error: Key length not 128/192/256 bits!");
                    return false;
            }

            foreach (var section in SectionHeaders)
            {
                if (section.Name.Trim('\0') == sectionName)
                {
                    /* Data format: [key_size | key | iv_size | iv | data_size | data] */
                    byte[] bIvSize = { 0x10 };                                      // IV size  : 1 byte -> value = 16
                    byte[] bKeySize = { ks_value };                                 // Key size : 1 byte -> value = 32
                    byte[] bDataSize = BitConverter.GetBytes((long)dataEmbed.Length);     // Data size: 8 byte -> value = data_size (eg: 6E0 - 1760)

                    Array.Copy(bKeySize, 0, _buffer, section.PointerToRawData, bKeySize.Length);
                    Array.Copy(key, 0, _buffer, section.PointerToRawData + bKeySize.Length, key.Length);
                    Array.Copy(bIvSize, 0, _buffer, section.PointerToRawData + bKeySize.Length + key.Length, bIvSize.Length);
                    Array.Copy(iv, 0, _buffer, section.PointerToRawData + bKeySize.Length + key.Length + bIvSize.Length, iv.Length);
                    Array.Copy(bDataSize, 0, _buffer, section.PointerToRawData + bKeySize.Length + key.Length + bIvSize.Length + iv.Length, bDataSize.Length);
                    Array.Copy(dataEmbed, 0, _buffer, section.PointerToRawData + bKeySize.Length + key.Length + bIvSize.Length + iv.Length + bDataSize.Length, dataEmbed.Length);

                    //Reparsing -> Get _buffer with new format PE
                    if (!Parser())
                    {
                        Console.WriteLine("Reparsing buffer failed!");
                        return false;
                    }
                    return true;
                }
            }
            return false;
        }
        public bool AppendAndEmbedSection(string sectionName, byte[] dataEmbed, uint sectionSize, uint sectionFlag)
        {
            //Check size 
            long sizeOfFile = PESize;
            long sizeOfDataEmbed = dataEmbed.Length;
            if (sectionSize == 0)
            {
                sectionSize = (uint)(sizeOfDataEmbed);
            }
            if (sectionSize < sizeOfDataEmbed)
            {
                Console.WriteLine("The minimum file size is {0}.", (uint)(sizeOfDataEmbed));
                return false;
            }
            if (sectionSize > (uint)((1.8e+9) - sizeOfFile))
            {
                Console.WriteLine("The total size limit of a PE file is 4 GiB (4.294967 GB).");
                Console.WriteLine("The maximum file size is 1.8 GB.");
                Console.WriteLine("Size limit is close to {0} byte.", (uint)(1.8e+9 - sizeOfFile));
                return false;
            }
            //Check for section exist
            if (IsSectionExist(sectionName))
            {
                Console.WriteLine($"Section '{sectionName}' already exists.");
                return false; 
            }
            //Append new section
            if (!AppendNewSection(sectionName, sectionSize, sectionFlag))
            {
                Console.WriteLine("Append new section failed, cannot write data to file!");
                return false;
            }
            //Embed data to section
            if (!EmbedDataToSection(sectionName, dataEmbed))
            {
                Console.WriteLine("Can't embed data in {0} section!", sectionName);
                RemoveSection(sectionName);
                return false;
            }
            return true;
        }
        public bool AppendAndEmbedSectionWithAes(string sectionName, byte[] dataEmbed, uint sectionSize, uint sectionFlag, byte[] key, byte[] iv)
        {
            //Check size 
            long sizeOfFile = PESize;
            long sizeOfDataEmbed = dataEmbed.Length;
            if (sectionSize == 0)
            {
                sectionSize = (uint)(sizeOfDataEmbed);
            }
            if (sectionSize < sizeOfDataEmbed)
            {
                Console.WriteLine("The minimum file size is {0}.", (uint)(sizeOfDataEmbed));
                return false;
            }
            if (sectionSize > (uint)((1.8e+9) - sizeOfFile))
            {
                Console.WriteLine("The total size limit of a PE file is 4 GiB (4.294967 GB).");
                Console.WriteLine("The maximum file size is 1.8 GB.");
                Console.WriteLine("Size limit is close to {0} byte.", (uint)(1.8e+9 - sizeOfFile));
                return false;
            }
            //Check for section exist
            if (IsSectionExist(sectionName))
            {
                Console.WriteLine($"Section '{sectionName}' already exists.");
                return false;
            }
            //Append new section
            if (!AppendNewSection(sectionName, sectionSize, sectionFlag))
            {
                Console.WriteLine("Append new section failed, cannot write data to file!");
                return false;
            }
            //Encrypt data config
            byte[] dataEncrypted = AesEncrypt(CipherMode.CBC, dataEmbed, key, iv);

            //Embed data encrypted to section
            if (!EmbedDataToSectionWithAes(sectionName, dataEncrypted, key, iv))
            {
                Console.WriteLine("Can't embed data in {0} section!", sectionName);
                RemoveSection(sectionName);
                return false;
            }
            return true;
        }
        public byte[] ExtractSectionWithName(string name)
        {
            byte[] data = null;
            foreach (var section in SectionHeaders)
            {
                if (section.Name.Trim('\0') == name.Trim('\0'))
                {
                    data = new byte[section.SizeOfRawData];
                    Array.Copy(_buffer, section.PointerToRawData, data, 0, section.SizeOfRawData);
                    break;
                }
            }
            return data;
        }
        public byte[] ExtractSectionWithSign(string sign)
        {
            byte[] data = null;
            byte[] sign_bytes = Encoding.ASCII.GetBytes(sign);
            foreach (var section in SectionHeaders)
            {
                for (int i = 0; i < _buffer.Length; i++)
                {
                    if (_buffer.Skip(i).Take(sign_bytes.Length).SequenceEqual(sign_bytes))
                    {
                        data = new byte[section.SizeOfRawData];
                        Array.Copy(_buffer, section.PointerToRawData, data, 0, section.SizeOfRawData);
                        break;
                    }
                }
            }
            return data;
        }
        public bool SaveInParts(string path)
        {
            try {
                int size = 0;
                byte[] buffer = new byte[1024];
                var fStream = File.OpenWrite(path);
                fStream.SetLength(_buffer.Length);
                while (true)
                {
                    if (size > _buffer.Length - 1024)
                    {
                        Array.Copy(_buffer, size, buffer, 0, _buffer.Length - size);
                        fStream.Write(buffer, 0, _buffer.Length - size);
                        break;
                    }
                    Array.Copy(_buffer, size, buffer, 0, 1024);
                    fStream.Write(buffer, 0, 1024);
                    size += 1024;
                }
                fStream.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: {0}", ex.Message);
                return false;
            }
            return true;
        }
        public bool Save(string path)
        {
            try
            {
                File.WriteAllBytes(path, ToArray());
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }
        private bool Parser()
        {
            int offset = 0;
            try
            {
                DosHeader = new DosHeader(_buffer, offset);
                offset += DosHeader.Lfanew;
                offset += sizeof(uint);
                FileHeader = new FileHeader(_buffer, offset);
                offset += FileHeader.RawSize;
                OptionalHeader = new OptionalHeader(_buffer, offset);
                offset += OptionalHeader.RawSize;
                SectionHeaders = new SectionHeader[FileHeader.NumberOfSections];
                for (int i = 0; i < SectionHeaders.Length; i++)
                {
                    SectionHeaders[i] = new SectionHeader(_buffer, offset);
                    offset += SectionHeaders[i].RawSize;
                }
                var address = OptionalHeader.DataDirectories[(int)DataDirectoryIndex.Debug].Address;
                if (address != 0)
                {
                    DebugDirectory = new DebugDirectory(_buffer, Rva2Offset(address));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: {0}", ex.Message);
                return false;
            }
            return true;
        }
        private byte[] AesEncrypt(CipherMode mode, byte[] plainText, byte[] key, byte[] iv)
        {
            if (plainText == null || plainText.Length <= 0)
                throw new ArgumentNullException("plainText");
            if (key == null || key.Length <= 0)
                throw new ArgumentNullException("key");
            if (iv == null || iv.Length <= 0)
                throw new ArgumentNullException("iv");

            byte[] encrypted;
            using (AesManaged aes = new AesManaged())
            {
                aes.IV = iv;
                aes.Key = key;
                aes.Mode = mode;
                aes.Padding = PaddingMode.PKCS7;

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        csEncrypt.Write(plainText, 0, plainText.Length);
                    }
                    encrypted = msEncrypt.ToArray();
                }
            }
            return encrypted;
        }
        private byte[] AesDecrypt(CipherMode mode, byte[] cipherText, byte[] key, byte[] iv)
        {
            if (cipherText == null || cipherText.Length <= 0)
                throw new ArgumentNullException("cipherText");
            if (key == null || key.Length <= 0)
                throw new ArgumentNullException("key");
            if (iv == null || iv.Length <= 0)
                throw new ArgumentNullException("iv");

            byte[] decrypted;
            using (AesManaged aes = new AesManaged())
            {
                aes.IV = iv;
                aes.Key = key;
                aes.Mode = mode;
                aes.Padding = PaddingMode.PKCS7;

                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
                using (MemoryStream msDecrypt = new MemoryStream())
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Write))
                    {
                        csDecrypt.Write(cipherText, 0, cipherText.Length);
                    }
                    decrypted = msDecrypt.ToArray();
                }
            }
            return decrypted;
        }
        private Int32 Rva2Offset(UInt32 rva)
        {
            Int32 offset = -1;
            foreach (var sec in SectionHeaders)
            {
                if (sec.VirtualAddress <= rva && rva < sec.VirtualAddress + sec.VirtualSize)
                {
                    offset = Convert.ToInt32(sec.PointerToRawData + rva - sec.VirtualAddress);
                    break;
                }
            }
            return offset;
        }
        private UInt32 Offset2Rva(Int32 offset)
        {
            UInt32 rva = 0;
            for (Int32 i = 0; i < FileHeader.NumberOfSections; i++)
            {
                if (offset >= SectionHeaders[i].PointerToRawData && offset < SectionHeaders[i].PointerToRawData + SectionHeaders[i].SizeOfRawData)
                {
                    rva = Convert.ToUInt32(SectionHeaders[i].VirtualAddress + (offset - SectionHeaders[i].PointerToRawData));
                }
            }
            return rva;
        }
        private UInt32 Align(UInt32 value, UInt32 alignment)
        {
            UInt32 remainder = value % alignment;
            if (remainder != 0)
            {
                return value + alignment - remainder;
            }
            return value;
        }
    }
}
