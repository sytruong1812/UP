﻿using System;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace PEHelper.Pe
{
    public abstract class SafeStruct
    {
        protected int _offset { get; set; } = 0;
        protected Byte[] _buffer { get; set; }
        protected SafeStruct(Byte[] buffer, int offset)
        {
            _buffer = buffer;
            _offset = offset;
        }
        public abstract int RawSize { get; }
        public bool Append(uint newSize)
        {
            if (_buffer == null) {
                return false;
            }
            uint oldSize = (uint)_buffer.Length;
            if (newSize == 0 || newSize < oldSize)
            {
                return false;
            }
            Byte[] new_buffer = new Byte[oldSize];
            Array.Copy(_buffer, new_buffer, oldSize);
            _buffer = new Byte[newSize];
            Array.Copy(new_buffer, _buffer, oldSize);
            return true;
        }
        public bool AppendBytes(Byte[] bytes)
        {
            if (_buffer == null) {
                return false;
            }
            var oldSize = _buffer.Length;
            var newBuffer = new byte[_buffer.Length + bytes.Length];
            Array.Copy(_buffer, newBuffer, oldSize);
            Array.Copy(bytes, 0, newBuffer, oldSize, bytes.Length);

            _buffer = newBuffer;

            return true;
        }
        public void RemoveRange(long offset, long length)
        {
            if (offset < 0 || length < 0 || offset + length > _buffer.Length)
            {
                throw new ArgumentOutOfRangeException("Invalid offset or length.");
            }
            // Create a new buffer with the reduced size
            var newBuffer = new byte[_buffer.Length - length];
            // Copy the part before the offset
            Array.Copy(_buffer, 0, newBuffer, 0, offset);
            // Copy the part after the removed range
            Array.Copy(_buffer, offset + length, newBuffer, offset, _buffer.Length - (offset + length));
            // Update the buffer reference
            _buffer = newBuffer;
        }
        public void WriteBytes(long offset, Byte[] bytes)
        {
            Array.Copy(bytes, 0, _buffer, offset, bytes.Length);
        }
        public void WriteUInt(long offset, uint value)
        {
            _buffer[offset + 1] = (byte)value;
        }
        public Byte[] AsSpan(long offset, long length)
        {
            byte[] span = new byte[length];
            Array.Copy(_buffer, offset, span, 0, length);
            return span;
        }
        public Byte[] ToArray()
        {
            return _buffer.ToArray();
        }
        protected Byte ToByte(object startIndex)
        {
            return _buffer[_offset + (int)startIndex];
        }
        protected Byte[] ToBytes(object startIndex, int len)
        {
            var result = new byte[len];
            Array.Copy(_buffer, _offset + Convert.ToInt32(startIndex), result, 0, result.Length);
            return result;
        }
        protected UInt16 ToUInt16(object startIndex)
        {
            return BitConverter.ToUInt16(ToBytes(startIndex, sizeof(UInt16)), 0);
        }
        protected UInt32 ToUInt32(object startIndex)
        {
            return BitConverter.ToUInt32(ToBytes(startIndex, sizeof(UInt32)), 0);
        }
        protected UInt64 ToUInt64(object startIndex)
        {
            return BitConverter.ToUInt64(ToBytes(startIndex, sizeof(UInt64)), 0);
        }
        protected string ToString(object startIndex, int count, Encoding encoding)
        {
            return encoding.GetString(_buffer, _offset + (int)startIndex, count);
        }
        protected string ToUtf16String(object startIndex, int count)
        {
            if (count < 0)
            {
                int i = _offset + (int)startIndex;
                count = 0;
                while (BitConverter.ToInt16(_buffer, i + count) != 0)
                {
                    count += 2;
                }
            }
            return ToString(startIndex, count, Encoding.Unicode);
        }
        protected string ToUft8String(object startIndex, int count)
        {
            if (count < 0)
            {
                int i = _offset + (int)startIndex;
                count = 0;
                while (_buffer[i + count] != 0)
                {
                    count++;
                }
            }
            return ToString(startIndex, count, Encoding.UTF8);
        }
        protected Guid ToGuid(object startIndex)
        {
            return new Guid(ToBytes(startIndex, 16));
        }
        protected void SetBytes(Byte[] value, object startIndex)
        {
            Array.Copy(value, 0, _buffer, _offset + (int)startIndex, value.Length);
        }
        protected void SetByte(Byte value, object startIndex)
        {
            _buffer[_offset + (int)startIndex] = value;
        }
        protected void SetUInt16(UInt16 value, object startIndex)
        {
            SetBytes(BitConverter.GetBytes(value), startIndex);
        }
        protected void SetUInt32(UInt32 value, object startIndex)
        {
            SetBytes(BitConverter.GetBytes(value), startIndex);
        }
        protected void SetUInt64(UInt64 value, object startIndex)
        {
            SetBytes(BitConverter.GetBytes(value), startIndex);
        }
        protected void SetString(string value, object startIndex, Encoding encoding)
        {
            Byte[] tmp = encoding.GetBytes(value);
            Array.Copy(tmp, 0, _buffer, _offset + (int)startIndex, tmp.Length);
        }
        protected void SetUtf16String(string value, object startIndex)
        {
            SetString(value, startIndex, Encoding.Unicode);
        }
        protected void SetUft8String(string value, object startIndex)
        {
            SetString(value, startIndex, Encoding.UTF8);
        }
        protected void SetGuid(Guid value, object startIndex)
        {
            SetBytes(value.ToByteArray(), startIndex);
        }
    }
}
