﻿#pragma once
#if OPTION_1

#include <array>
#include <cstring>
#include <string.h>

// Create the section
#pragma section(".stub", read, write)
/*
E	Execute	    The section is executable
R	Read	    Allows read operations on data
W	Write	    Allows write operations on data
S	Shared	    Shares the section among all processes that load the image
D	Discardable	Marks the section as discardable
K	Cacheable	Marks the section as not cacheable
P	Pageable	Marks the section as not pageable
*/

// Declare a struct to hold the constant data
struct ConfigData {
    int app_id;                     // Application ID
    unsigned int user_id;                    // User ID
    unsigned long long time_zone;            // Time zone (could be in seconds or minutes offset)
    char server_address[32];        // Server address (e.g., IP address or hostname)
    char email[64];                 // Email address
    wchar_t full_name[64];         // Full name (wide-character string for Unicode)
    unsigned char iv_data[16];            // Initialization Vector (IV) for encryption
    unsigned char key_data[32];           // Encryption key data
    unsigned char data_encrypted[1024];   // Encrypted data (could be file contents, etc.)
};

// Reset to default constant segment
#pragma section() 

#endif //OPTION_1
