﻿using System;

namespace PEHelper.Pe
{
    public class DebugDirectory : SafeStruct
    {
        private enum Offset : int
        {
            Characteristics = 0,
            TimeDateStamp = Characteristics + sizeof(UInt32),
            MajorVersion = TimeDateStamp + sizeof(UInt32),
            MinorVersion = MajorVersion + sizeof(UInt16),
            Type = MinorVersion + sizeof(UInt16),
            SizeOfData = Type + sizeof(UInt32),
            AddressOfRawData = SizeOfData + sizeof(UInt32),
            PointerToRawData = AddressOfRawData + sizeof(UInt32),
            DebugDirectorySize = PointerToRawData + sizeof(UInt32)
        }
        public UInt32 Characteristics
        {
            get
            {
                return ToUInt32(Offset.Characteristics);
            }
            set
            {
                SetUInt32(value, Offset.Characteristics);
            }
        }
        public UInt32 TimeDateStamp
        {
            get
            {
                return ToUInt32(Offset.TimeDateStamp);
            }
            set
            {
                SetUInt32(value, Offset.TimeDateStamp);
            }
        }
        public UInt16 MajorVersion
        {
            get
            {
                return ToUInt16(Offset.MajorVersion);
            }
            set
            {
                SetUInt16(value, Offset.MajorVersion);
            }
        }
        public UInt16 MinorVersion
        {
            get
            {
                return ToUInt16(Offset.MinorVersion);
            }
            set
            {
                SetUInt16(value, Offset.MinorVersion);
            }
        }
        public UInt32 Type
        {
            get
            {
                return ToUInt32(Offset.Type);
            }
            set
            {
                SetUInt32(value, Offset.Type);
            }
        }
        public UInt32 SizeOfData
        {
            get
            {
                return ToUInt32(Offset.SizeOfData);
            }
            set
            {
                SetUInt32(value, Offset.SizeOfData);
            }
        }
        public UInt32 AddressOfRawData
        {
            get
            {
                return ToUInt32(Offset.AddressOfRawData);
            }
            set
            {
                SetUInt32(value, Offset.AddressOfRawData);
            }
        }
        public UInt32 PointerToRawData
        {
            get
            {
                return ToUInt32(Offset.PointerToRawData);
            }
            set
            {
                SetUInt32(value, Offset.PointerToRawData);
            }
        }
        public DebugInfo DebugInfo { get; private set; }
        public DebugDirectory(Byte[] buffer, int offset = 0) : base(buffer, offset)
        {
            if (PointerToRawData != 0)
            {
                DebugInfo = new DebugInfo(buffer, Convert.ToInt32(PointerToRawData));
            }
        }
        public override int RawSize
        {
            get
            {
                return (int)Offset.DebugDirectorySize;
            }
        }
    }
}
