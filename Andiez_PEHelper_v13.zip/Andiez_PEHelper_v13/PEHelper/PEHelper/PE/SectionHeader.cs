﻿using System;

namespace PEHelper.Pe
{
    public class SectionHeader : SafeStruct
    {
        private enum Offset
        {
            Name = 0,
            VirtualSize = Name + 8,
            VirtualAddress = VirtualSize + sizeof(UInt32),
            SizeOfRawData = VirtualAddress + sizeof(UInt32),
            PointerToRawData = SizeOfRawData + sizeof(UInt32),
            PointerToRelocations = PointerToRawData + sizeof(UInt32),
            PointerToLinenumbers = PointerToRelocations + sizeof(UInt32),
            NumberOfRelocations = PointerToLinenumbers + sizeof(UInt32),
            NumberOfLinenumbers = NumberOfRelocations + sizeof(UInt16),
            Characteristics = NumberOfLinenumbers + sizeof(UInt16),
            SectionHeaderSize = Characteristics + sizeof(UInt32)
        }
        public string Name
        {
            get
            {
                return ToUft8String(Offset.Name, 8);
            }
            set
            {
                var old = Name;
                for (int i = value.Length; i < old.Length; i++)
                {
                    value += '\0';
                }
                SetUft8String(value, Offset.Name);
            }
        }
        public UInt32 VirtualSize
        {
            get
            {
                return ToUInt32(Offset.VirtualSize);
            }
            set
            {
                SetUInt32(value, Offset.VirtualSize);
            }
        }
        public UInt32 VirtualAddress
        {
            get
            {
                return ToUInt32(Offset.VirtualAddress);
            }
            set
            {
                SetUInt32(value, Offset.VirtualAddress);
            }
        }
        public UInt32 SizeOfRawData
        {
            get
            {
                return ToUInt32(Offset.SizeOfRawData);
            }
            set
            {
                SetUInt32(value, Offset.SizeOfRawData);
            }
        }
        public UInt32 PointerToRawData
        {
            get
            {
                return ToUInt32(Offset.PointerToRawData);
            }
            set
            {
                SetUInt32(value, Offset.PointerToRawData);
            }
        }
        public UInt32 PointerToRelocations
        {
            get
            {
                return ToUInt32(Offset.PointerToRelocations);
            }
            set
            {
                SetUInt32(value, Offset.PointerToRelocations);
            }
        }
        public UInt32 PointerToLinenumbers
        {
            get
            {
                return ToUInt32(Offset.PointerToLinenumbers);
            }
            set
            {
                SetUInt32(value, Offset.PointerToLinenumbers);
            }
        }
        public UInt16 NumberOfRelocations
        {
            get
            {
                return ToUInt16(Offset.NumberOfRelocations);
            }
            set
            {
                SetUInt16(value, Offset.NumberOfRelocations);
            }
        }
        public UInt16 NumberOfLinenumbers
        {
            get
            {
                return ToUInt16(Offset.NumberOfLinenumbers);
            }
            set
            {
                SetUInt16(value, Offset.NumberOfLinenumbers);
            }
        }
        public UInt32 Characteristics
        {
            get
            {
                return ToUInt32(Offset.Characteristics);
            }
            set
            {
                SetUInt32(value, Offset.Characteristics);
            }
        }
        public SectionHeader(Byte[] buffer, int offset = 0) : base(buffer, offset)
        {

        }
        public override int RawSize
        {
            get
            {
                return (int)Offset.SectionHeaderSize;
            }
        }
    }
}
