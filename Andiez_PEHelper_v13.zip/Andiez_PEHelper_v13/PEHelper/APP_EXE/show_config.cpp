﻿#include <io.h> 
#include <fcntl.h> 
#include <iostream>
#pragma warning(disable: 6031)

#include "show_config.h"

void ShowConfig(
    int app_id, 
    unsigned int user_id,
    unsigned long long time_zone,
    const char* email, 
    const char* server_address,
    const wchar_t* full_name,
    const unsigned char* iv_data,
    const unsigned char* key_data,
    const unsigned char* data_encrypted)
{
    std::cout << "Show App ID: "            << app_id << std::endl;
    std::cout << "Show User ID: "           << user_id << std::endl;
    std::cout << "Show Time Zone: "         << time_zone << std::endl;
    std::cout << "Show Email: "             << email << std::endl;
    std::cout << "Show Server Address: "    << server_address << std::endl;
    _setmode(_fileno(stdout), _O_U16TEXT);
    std::wcout << L"Show Full Name: "       << full_name << std::endl;
    _setmode(_fileno(stdout), _O_TEXT);
    std::cout << "Show IV decrypt data: "   << iv_data << std::endl;
    std::cout << "Show Key decrypt data: "  << key_data << std::endl;
    std::cout << "Show Data encrypted: "    << data_encrypted << std::endl;
}

void ShowConfig1(
    const int* app_id,
    const unsigned int* user_id,
    const unsigned long long* time_zone,
    const char* email,
    const char* server_address,
    const wchar_t* full_name, 
    const unsigned char* iv_data,
    const unsigned char* key_data,
    const unsigned char* data_encrypted)
{
    printf("Show App ID: 0x%X\n", *app_id);
    printf("Show User ID: 0x%X\n", *user_id);
    printf("Show Time Zone: 0x%llX\n", *time_zone);
    printf("Show Email: %s\n", email);
    printf("Show Server Address: %s\n", server_address);
    _setmode(_fileno(stdout), _O_U16TEXT);
    wprintf(L"Show Full Name: %s\n", full_name);
    _setmode(_fileno(stdout), _O_TEXT);
    printf("Show IV decrypt data: %s\n", iv_data);
    printf("Show Key decrypt data: %s\n", key_data);
    printf("Show Data encrypted: %s\n", data_encrypted); 
}

void ShowConfig2(const int32_t& app_id,
    const uint32_t& user_id,
    const uint64_t& time_zone,
    const std::string& email,
    const std::string& server_address, 
    const std::wstring& full_name, 
    const uint8_t* iv_data,
    const uint8_t* key_data,
    const uint8_t* data_encrypted)
{
    std::cout << "Show App ID: " << app_id << std::endl;
    std::cout << "Show User ID: " << user_id << std::endl;
    std::cout << "Show Time Zone: " << time_zone << std::endl;
    std::cout << "Show Email: " << email << std::endl;
    std::cout << "Show Server Address: " << server_address << std::endl;
    _setmode(_fileno(stdout), _O_U16TEXT);
    std::wcout << L"Show Full Name: " << full_name << std::endl;
    _setmode(_fileno(stdout), _O_TEXT);
    std::cout << "Show IV decrypt data: " << iv_data << std::endl;
    std::cout << "Show Key decrypt data: " << key_data << std::endl;
    std::cout << "Show Data encrypted: " << data_encrypted << std::endl;
}
