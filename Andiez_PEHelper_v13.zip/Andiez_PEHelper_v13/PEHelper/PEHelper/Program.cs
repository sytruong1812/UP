﻿using System;
using System.Text;
using System.Runtime.InteropServices;
using PEHelper.Pe;

namespace PEHelper
{
    internal class Program
    {
        public static void OPTION_1()
        {
            Console.Write("=> Input path: ");
            string path_release = Console.ReadLine();

            DataConfig new_config = new DataConfig
            {
                app_id = 0xFFFFFF,
                user_id = 0xDDDDDDDD,
                time_zone = 0xBBBBBBBBBBBB,
                server_address = new byte[32],
                email = new byte[64],
                full_name = new byte[128],
                iv_data = new byte[16],
                key_data = new byte[32],
                data_encrypted = new byte[1024]
            };
            // Set new values5
            byte[] server_address_temp = Encoding.ASCII.GetBytes("127.0.0.1");
            Array.Copy(server_address_temp, 0, new_config.server_address, 0, server_address_temp.Length);
            byte[] email_temp = Encoding.ASCII.GetBytes("xyz@gmail.com");
            Array.Copy(email_temp, 0, new_config.email, 0, email_temp.Length);
            byte[] full_name_temp = Encoding.Unicode.GetBytes("Nguyễn Văn An");
            Array.Copy(full_name_temp, 0, new_config.full_name, 0, full_name_temp.Length);
            byte[] iv_decrypt_data_temp = Encoding.ASCII.GetBytes("Iv16Bytes");
            Array.Copy(iv_decrypt_data_temp, 0, new_config.iv_data, 0, iv_decrypt_data_temp.Length);
            byte[] key_decrypt_data_temp = Encoding.ASCII.GetBytes("Key32Bytes");
            Array.Copy(key_decrypt_data_temp, 0, new_config.key_data, 0, key_decrypt_data_temp.Length);
            byte[] data_encrypted = Encoding.ASCII.GetBytes("ThisDataEncrypted");
            Array.Copy(data_encrypted, 0, new_config.data_encrypted, 0, data_encrypted.Length);

            if (!Option1.UpdateConfig(path_release, ".stub", new_config))
            {
                Console.WriteLine("Failed to change configuration data!");
            }
            else
            {
                Console.WriteLine("Update configuration data successfully!");
            }
        }
        public static void OPTION_2()
        {
            Console.Write("=> Input path: ");
            string path_release = Console.ReadLine(); 
            
            DataConfig new_config = new DataConfig
            {
                app_id = 0xFFFFFF,
                user_id = 0xDDDDDDDD,
                time_zone = 0xBBBBBBBBBBBB,
                server_address = new byte[32],
                email = new byte[64],
                full_name = new byte[128],
                iv_data = new byte[16],
                key_data = new byte[32],
                data_encrypted = new byte[1024]
            };
            // Set new values5
            byte[] server_address_temp = Encoding.ASCII.GetBytes("127.0.0.1");
            Array.Copy(server_address_temp, 0, new_config.server_address, 0, server_address_temp.Length);
            byte[] email_temp = Encoding.ASCII.GetBytes("xyz@gmail.com");
            Array.Copy(email_temp, 0, new_config.email, 0, email_temp.Length);
            byte[] full_name_temp = Encoding.Unicode.GetBytes("Nguyễn Văn An");
            Array.Copy(full_name_temp, 0, new_config.full_name, 0, full_name_temp.Length);
            byte[] iv_decrypt_data_temp = Encoding.ASCII.GetBytes("Iv16Bytes");
            Array.Copy(iv_decrypt_data_temp, 0, new_config.iv_data, 0, iv_decrypt_data_temp.Length);
            byte[] key_decrypt_data_temp = Encoding.ASCII.GetBytes("Key32Bytes");
            Array.Copy(key_decrypt_data_temp, 0, new_config.key_data, 0, key_decrypt_data_temp.Length);
            byte[] data_encrypted = Encoding.ASCII.GetBytes("ThisDataEncrypted");
            Array.Copy(data_encrypted, 0, new_config.data_encrypted, 0, data_encrypted.Length);

            byte[] key =
            {
                0xD6, 0x23, 0xB8, 0xEF, 0x62, 0x26, 0xCE, 0xC3, 0xE2, 0x4C, 0x55, 0x12,
                0x7D, 0xE8, 0x73, 0xE7, 0x83, 0x9C, 0x77, 0x6B, 0xB1, 0xA9, 0x3B, 0x57,
                0xB2, 0x5F, 0xDB, 0xEA, 0x0D, 0xB6, 0x8E, 0xA2
            };
            byte[] iv =
            {
                0x18, 0x42, 0x31, 0x2D, 0xFC, 0xEF, 0xDA, 0xB6, 0xB9, 0x49, 0xF1, 0x0D,
                0x03, 0x7E, 0x7E, 0xBD
            };
            if (!Option2.UpdateConfig(path_release,
                ".stub",
                new_config,
                Encoding.ASCII.GetString(key),
                Encoding.ASCII.GetString(iv)))
            {
                Console.WriteLine("Failed to update configuration data!");
            }
            else
            {
                Console.WriteLine("Update configuration data successfully!");
            }
        }
        public static void OPTION_3()
        {
            Console.Write("=> Input path: ");
            string path_release = Console.ReadLine();

            DataConfig new_config = new DataConfig
            {
                app_id = 0xFFFFFF,
                user_id = 0xDDDDDDDD,
                time_zone = 0xBBBBBBBBBBBB,
                server_address = new byte[32],
                email = new byte[64],
                full_name = new byte[128],
                iv_data = new byte[16],
                key_data = new byte[32],
                data_encrypted = new byte[1024]
            };
            // Set new values
            byte[] server_address_temp = Encoding.ASCII.GetBytes("127.0.0.1");
            Array.Copy(server_address_temp, 0, new_config.server_address, 0, server_address_temp.Length);
            byte[] email_temp = Encoding.ASCII.GetBytes("xyz@gmail.com");
            Array.Copy(email_temp, 0, new_config.email, 0, email_temp.Length);
            byte[] full_name_temp = Encoding.Unicode.GetBytes("Nguyễn Văn An");
            Array.Copy(full_name_temp, 0, new_config.full_name, 0, full_name_temp.Length);
            byte[] iv_decrypt_data_temp = Encoding.ASCII.GetBytes("Iv16Bytes");
            Array.Copy(iv_decrypt_data_temp, 0, new_config.iv_data, 0, iv_decrypt_data_temp.Length);
            byte[] key_decrypt_data_temp = Encoding.ASCII.GetBytes("Key32Bytes");
            Array.Copy(key_decrypt_data_temp, 0, new_config.key_data, 0, key_decrypt_data_temp.Length);
            byte[] data_encrypted = Encoding.ASCII.GetBytes("ThisDataEncrypted");
            Array.Copy(data_encrypted, 0, new_config.data_encrypted, 0, data_encrypted.Length);

            if (!Option3.UpdateConfig(path_release, "SIGN:OLD", new_config))
            {
                Console.WriteLine("Failed to update configuration data!");
            }
            else
            {
                Console.WriteLine("Update configuration data successfully!");
            }
        }
        public static void OPTION_4()
        {

        }
        static void Main(string[] args)
        {  
            while (true)
            {
                Console.WriteLine("====================[ PROGRAM TEST ]=====================");
                Console.WriteLine(" [1] OPTION 1");
                Console.WriteLine(" [2] OPTION 2");
                Console.WriteLine(" [3] OPTION 3");
                Console.WriteLine(" [4] OPTION 4");
                Console.WriteLine(" [E] Exit program!");
                Console.Write("=> Input a number: ");

                string input = Console.ReadLine();
                if (input.ToUpper().CompareTo("E") == 0)
                {
                    System.Environment.Exit(1);
                }
                if (input != "")
                {
                    switch (int.Parse(input))
                    {
                        case 1:
                            Console.WriteLine("===================[ TEST_OPTION_1 ]======================");
                            OPTION_1();
                            break;
                        case 2:
                            Console.WriteLine("===================[ TEST_OPTION_2 ]======================");
                            OPTION_2();
                            break;
                        case 3:
                            Console.WriteLine("===================[ TEST_OPTION_3 ]======================");
                            OPTION_3();
                            break;
                        case 4:
                            Console.WriteLine("===================[ TEST_OPTION_4 ]======================");
                            OPTION_4();
                            break;
                        default:
                            Console.WriteLine("=> Invalid input!");
                            break;
                    }
                }
            }
        }
    }
}


