﻿using System;

namespace PEHelper.Pe
{
    public class FileHeader : SafeStruct
    {
        private enum Offset : int
        {
            Machine = 0,
            NumberOfSections = Machine + sizeof(UInt16),
            TimeDateStamp = NumberOfSections + sizeof(UInt16),
            PointerToSymbolTable = TimeDateStamp + sizeof(UInt32),
            NumberOfSymbols = PointerToSymbolTable + sizeof(UInt32),
            SizeOfOptionalHeader = NumberOfSymbols + sizeof(UInt32),
            Characteristics = SizeOfOptionalHeader + sizeof(UInt16),
            FileHeaderSize = Characteristics + sizeof(UInt16)
        }
        public UInt16 Machine
        {
            get
            {
                return ToUInt16(Offset.Machine);
            }
            set
            {
                SetUInt16(value, Offset.Machine);
            }
        }
        public UInt16 NumberOfSections
        {
            get
            {
                return ToUInt16(Offset.NumberOfSections);
            }
            set
            {
                SetUInt16(value, Offset.NumberOfSections);
            }
        }
        public UInt32 TimeDateStamp
        {
            get
            {
                return ToUInt32(Offset.TimeDateStamp);
            }
            set
            {
                SetUInt32(value, Offset.TimeDateStamp);
            }
        }
        public UInt32 PointerToSymbolTable
        {
            get
            {
                return ToUInt32(Offset.PointerToSymbolTable);
            }
            set
            {
                SetUInt32(value, Offset.PointerToSymbolTable);
            }
        }
        public UInt32 NumberOfSymbols
        {
            get
            {
                return ToUInt32(Offset.NumberOfSymbols);
            }
            set
            {
                SetUInt32(value, Offset.NumberOfSymbols);
            }
        }
        public UInt16 SizeOfOptionalHeader
        {
            get
            {
                return ToUInt16(Offset.SizeOfOptionalHeader);
            }
            set
            {
                SetUInt16(value, Offset.SizeOfOptionalHeader);
            }
        }
        public UInt16 Characteristics
        {
            get
            {
                return ToUInt16(Offset.Characteristics);
            }
            set
            {
                SetUInt16(value, Offset.Characteristics);
            }
        }
        public FileHeader(Byte[] buffer, int offset) : base(buffer, offset)
        {
        }
        public override int RawSize
        {
            get
            {
                return (int)Offset.FileHeaderSize;
            }
        }
    }
}
