﻿using System;

namespace PEHelper.Pe
{
    public class DebugInfo : SafeStruct
    {
        private enum Offset : int
        {
            Signature = 0,
            PdbSignature = Signature + sizeof(UInt32),
            PdbAge = PdbSignature + 16,
            PdbPath = PdbAge + sizeof(UInt32),
            DebugInfoSize = PdbPath
        }
        public UInt32 Signature
        {
            get
            {
                return ToUInt32(Offset.Signature);
            }
            set
            {
                SetUInt32(value, Offset.Signature);
            }
        }
        public Guid PdbSignature
        {
            get
            {
                return ToGuid(Offset.PdbSignature);
            }
            set
            {
                SetGuid(value, Offset.PdbSignature);
            }
        }
        public UInt32 PdbAge
        {
            get
            {
                return ToUInt32(Offset.PdbAge);
            }
            set
            {
                SetUInt32(value, Offset.PdbAge);
            }
        }
        public string PdbPath
        {
            get
            {
                return ToUft8String(Offset.PdbPath, -1);
            }
            set
            {
                var old = PdbPath;
                for (int i = value.Length; i < old.Length; i++)
                {
                    value += '\0';
                }
                SetUft8String(value, Offset.PdbPath);
            }
        }
        public DebugInfo(Byte[] buffer, int offset = 0) : base(buffer, offset)
        {

        }
        public override int RawSize
        {
            get
            {
                return (int)Offset.DebugInfoSize + PdbPath.Length;
            }
        }
    }
}
