﻿using System;

namespace PEHelper.Pe
{
    public class DataDirectory : SafeStruct
    {
        private enum Offset : int
        {
            Address = 0,
            Size = Address + sizeof(UInt32),
            DataDirectorySize = Size + sizeof(UInt32)
        }
        public UInt32 Address
        {
            get
            {
                return ToUInt32(Offset.Address);
            }
            set
            {
                SetUInt32(value, Offset.Address);
            }
        }
        public UInt32 Size
        {
            get
            {
                return ToUInt32(Offset.Size);
            }
            set
            {
                SetUInt32(value, Offset.Size);
            }
        }
        public DataDirectory(Byte[] buffer, int offset = 0) : base(buffer, offset)
        {

        }
        public override int RawSize
        {
            get
            {
                return (int)Offset.DataDirectorySize;
            }
        }
    }
}
