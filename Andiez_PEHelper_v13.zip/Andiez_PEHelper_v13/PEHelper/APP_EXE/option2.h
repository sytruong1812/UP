﻿#pragma once
#if OPTION_2

#include <io.h> 
#include <fcntl.h> 
#include <mbstring.h>
#include <SDKDDKVer.h>
#include <windows.h>
#include <winnt.h>
#include "pkcs7.h"
#include "aes.h"

// disable error macro -> align
#pragma warning (disable : 4146 6031)		
// align x down to the nearest multiple of align. align must be a power of 2.
#define P2ALIGNDOWN(x, align) ((x) & -(align))
// align x up to the nearest multiple of align. align must be a power of 2.
#define P2ALIGNUP(x, align) (-(-(x) & -(align)))

#ifdef _WIN64
#define MACHINE IMAGE_FILE_MACHINE_AMD64
#else
#define MACHINE IMAGE_FILE_MACHINE_I386
#endif

#define IV_OFFSET	1
#define KEYSIZE_OFFSET	1
#define DATASIZE_OFFSET 8

EXTERN_C IMAGE_DOS_HEADER __ImageBase;
#define HINST_THISCOMPONENT ((HINSTANCE)&__ImageBase)

// Declare a struct to hold the constant data
struct ConfigData {
	int app_id;								// Application ID
	unsigned int user_id;					// User ID
	unsigned long long time_zone;           // Time zone (could be in seconds or minutes offset)
	char server_address[32];				// Server address (e.g., IP address or hostname)
	char email[64];							// Email address
	wchar_t full_name[64];					// Full name (wide-character string for Unicode)
	unsigned char iv_data[16];				// Initialization Vector (IV) for encryption
	unsigned char key_data[32];				// Encryption key data
	unsigned char data_encrypted[1024];		// Encrypted data (could be file contents, etc.)
};

bool UpdateConfig(ConfigData* config, const char* secName)
{
	PIMAGE_DOS_HEADER dosHeader = (PIMAGE_DOS_HEADER)HINST_THISCOMPONENT;
	if (dosHeader != NULL)
	{
		if (dosHeader->e_magic != IMAGE_DOS_SIGNATURE)
		{
			return false;
		}
	}
	PIMAGE_NT_HEADERS ntHeaders = (PIMAGE_NT_HEADERS)((UINT_PTR)HINST_THISCOMPONENT + dosHeader->e_lfanew);
	if (ntHeaders == NULL)
	{
		return false;
	}
	if (ntHeaders->Signature != IMAGE_NT_SIGNATURE || ntHeaders->FileHeader.Machine != MACHINE)
	{
		return false;
	}
	/*=====================[Extracting data]===============================*/
	WORD numberOfSections = ntHeaders->FileHeader.NumberOfSections;
	PIMAGE_SECTION_HEADER section = IMAGE_FIRST_SECTION(ntHeaders);
	for (int i = 0; i < numberOfSections; i++)
	{
		if (strcmp((char*)section[i].Name, secName) == 0)
		{
			BYTE* ptr = (BYTE*)(PBYTE)((UINT_PTR)HINST_THISCOMPONENT + section[i].VirtualAddress);
			
			/*==========================[Parser]===================================*/
			/* Format: [key_size | key | iv_size | iv | data_size | data] */
			size_t key_size = static_cast<int>(ptr[0]);
			BYTE* pkey = ptr + KEYSIZE_OFFSET;

			size_t iv_size = static_cast<int>(ptr[key_size + KEYSIZE_OFFSET]);
			BYTE* piv = ptr + (key_size + KEYSIZE_OFFSET + IV_OFFSET);

			size_t data_size = 0;
			memcpy(&data_size, ptr + key_size + KEYSIZE_OFFSET + iv_size + IV_OFFSET, DATASIZE_OFFSET);
			BYTE* pdata = ptr + (key_size + KEYSIZE_OFFSET + iv_size + IV_OFFSET + DATASIZE_OFFSET);

			/*============================[Decrypt data]============================*/
			AES aes(AESKeyLength::AES_256);
			BYTE* pdata_decrypted = new BYTE[data_size];
			aes.decryptCBC(pdata, data_size, pkey, piv, pdata_decrypted);
			PKCS7_unPadding* un_pad = removePadding(pdata_decrypted, data_size);
			ConfigData* new_config = (ConfigData*)un_pad->dataWithoutPadding;
			
			config->app_id = new_config->app_id;
			config->user_id = new_config->user_id;
			config->time_zone = new_config->time_zone;
			strcpy(config->server_address, new_config->server_address);
			strcpy(config->email, new_config->email);
			wcscpy(config->full_name, new_config->full_name);
			_mbscpy(config->iv_data, new_config->iv_data);
			_mbscpy(config->key_data, new_config->key_data);
			_mbscpy(config->data_encrypted, new_config->data_encrypted);

			if (un_pad != NULL) {
				freeUnPaddingResult(un_pad);
			}
			if (pdata_decrypted != NULL) {
				delete[] pdata_decrypted;
			}
			return true;
		}
	}
	return false;
}

#endif  //OPTION_2
