﻿#pragma once
#if OPTION_3
#include <memory>
#include <string>
#include <type_traits>
#pragma warning(disable: 4309 4838)

// Little-endian
#define UINT32_TO_BYTE_ARRAY(value) \
    (value & 0xFF),           \
    ((value >> 8) & 0xFF),    \
    ((value >> 16) & 0xFF),   \
    ((value >> 24) & 0xFF)    \

// Constants
#define ARRAY_SIZE          2048
#define APP_ID_SIZE         sizeof(int)
#define USER_ID_SIZE        sizeof(unsigned int)
#define TIME_ZONE_SIZE      sizeof(unsigned long long)
#define SERVER_ADDR_SIZE    32
#define EMAIL_SIZE          64
#define FULLNAME_SIZE       (64 * sizeof(wchar_t))
#define IV_SIZE             16
#define KEY_SIZE            32
#define ENCRYPTED_DATA_SIZE 1024

/*
* Array format: [   SIGN    |   ARRAY_SIZE |   VALUE_SIZE |   VALUE   | ... ]
*               [   8 bytes |   4 bytes    |   4 bytes    |   .....   | ... ]
*/
const char config_value[ARRAY_SIZE] =
{
	// SIGN
	'S', 'I', 'G', 'N', ':', 'O', 'L', 'D',
	// Array size = 2048 (0x800 in little-endian)
	UINT32_TO_BYTE_ARRAY(ARRAY_SIZE),

	// app_id (4 bytes)
	UINT32_TO_BYTE_ARRAY(APP_ID_SIZE),
	0xAA, 0xAA, 0xAA, 0x00,

	// user_id (4 bytes)
	UINT32_TO_BYTE_ARRAY(USER_ID_SIZE),
	0xBB, 0xBB, 0xBB, 0xBB,

	// time_zone (8 bytes)
	UINT32_TO_BYTE_ARRAY(TIME_ZONE_SIZE),
	0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,

	// server_address (32 bytes)
	UINT32_TO_BYTE_ARRAY(SERVER_ADDR_SIZE),
	'1',  '9',  '2',  '.',  '1',  '6',  '8',  '.',
	'1',  '.',  '1',  0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,

	// email (64 bytes)
	UINT32_TO_BYTE_ARRAY(EMAIL_SIZE),
	'a',  'b',  'c',  '@',  'g',  'm',  'a',  'i',
	'l',  '.',  'c',  'o',  'm',  0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,

	// full_name (128 bytes for wchar_t[64])
	UINT32_TO_BYTE_ARRAY(FULLNAME_SIZE),
	'N',  0x00, 'g',  0x00, 'u',  0x00, 'y',  0x00,
	0xC5, 0x1E, 'n',  0x00, ' ',  0x00, 'S',  0x00,
	0xF9, 0x1E, 0x20, 0x00, 'T',  0x00, 'r',  0x00,
	0xB0, 0x01, 0xDD, 0x1E, 'n',  0x00, 'g',  0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,

	// iv_data (16 bytes)
	UINT32_TO_BYTE_ARRAY(IV_SIZE),
	0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0,
	0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0,

	// key_data (32 bytes)
	UINT32_TO_BYTE_ARRAY(KEY_SIZE),
	0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0,
	0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0,
	0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0,
	0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0,

	// data_encrypted (1024 bytes)
	UINT32_TO_BYTE_ARRAY(ENCRYPTED_DATA_SIZE),
	0xA3, 0xB7, 0x4C, 0x96, 0x5A, 0xBC, 0xD7, 0x0D,
	0xC8, 0x23, 0xEE, 0x98, 0xF3, 0xE2, 0xAB, 0x9E,
};

// Configuration structure
struct ConfigData
{
	int app_id;
	unsigned int user_id;
	unsigned long long time_zone;
	char server_address[SERVER_ADDR_SIZE];
	char email[EMAIL_SIZE];
	wchar_t full_name[FULLNAME_SIZE];
	unsigned char iv_data[IV_SIZE];
	unsigned char key_data[KEY_SIZE];
	unsigned char data_encrypted[ENCRYPTED_DATA_SIZE];
};

class ConfigParser
{
private:
	size_t current_offset;
	std::unique_ptr<ConfigData> config;
	// Start after SIGN(8) + ARRAY_SIZE(4)
	ConfigParser() : current_offset(12) 
	{
		config = std::make_unique<ConfigData>();
	}
public:
	// Get the singleton instance
	static ConfigParser& instance() {
		static ConfigParser instance;
		return instance;
	}

	template<typename T>
	bool getField(T* dest) {
		if (current_offset + sizeof(uint32_t) > ARRAY_SIZE)
		{
			return false;
		}
		// Get field size
		uint32_t field_size = *reinterpret_cast<const uint32_t*>(&config_value[current_offset]);
		current_offset += sizeof(uint32_t);
		if (current_offset + field_size > ARRAY_SIZE)
		{
			return false;
		}
		// Get field value
		memcpy(dest, &config_value[current_offset], field_size);
		current_offset += field_size;
		return true;
	}

	bool parseData() {
		uint32_t stored_size = *reinterpret_cast<const uint32_t*>(&config_value[8]);
		if (stored_size != ARRAY_SIZE)
		{
			return false;
		}
		if (!getField(&config->app_id)) return false;
		if (!getField(&config->user_id)) return false;
		if (!getField(&config->time_zone)) return false;
		if (!getField(config->server_address)) return false;
		if (!getField(config->email)) return false;
		if (!getField(config->full_name)) return false;
		if (!getField(config->iv_data)) return false;
		if (!getField(config->key_data)) return false;
		if (!getField(config->data_encrypted)) return false;

		return true;
	}

	ConfigData* getConfig() {
		return config.release();
	}
};

#endif  //OPTION_4