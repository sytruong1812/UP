﻿using System;
using System.Text;
using System.Runtime.InteropServices;
using PEHelper.Pe;

namespace PEHelper
{
    public class Option2
    {
        public static bool UpdateConfig(string pePath, string secName, DataConfig new_config, string key, string iv)
        {
            PeEditor pe = new PeEditor(pePath);
           
            // Convert the updated DataConfig back to byte array
            byte[] newData = Helper.StructToByteArray(new_config);

            // TEXT:  0x60000020: IMAGE_SCN_CNT_CODE | IMAGE_SCN_MEM_EXECUTE | IMAGE_SCN_MEM_READ ");
            // DATA:  0xC0000040: IMAGE_SCN_CNT_INITIALIZED_DATA | IMAGE_SCN_MEM_READ | IMAGE_SCN_MEM_WRITE");
            // RDATA: 0x40000040: IMAGE_SCN_CNT_INITIALIZED_DATA | IMAGE_SCN_MEM_READ ");
            if (!pe.AppendAndEmbedSectionWithAes(secName, newData, 5021, 0xC0000040, Encoding.ASCII.GetBytes(key), Encoding.ASCII.GetBytes(iv)))
            {
                Console.WriteLine("Embedd data into {0} section failed!", secName);
                return false;
            }
            if (!pe.Save(pePath))
            {
                return false;
            }
            return true;
        }
    }
}
