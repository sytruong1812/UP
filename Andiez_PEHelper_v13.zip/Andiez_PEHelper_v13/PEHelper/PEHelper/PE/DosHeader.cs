﻿using System;
using System.Collections.Generic;

namespace PEHelper.Pe
{
    public class DosHeader : SafeStruct
    {
        private enum Offset : int
        {
            Magic = 0,
            Cblp = Magic + sizeof(UInt16),
            Cp = Cblp + sizeof(UInt16),
            Crlc = Cp + sizeof(UInt16),
            Cparhdr = Crlc + sizeof(UInt16),
            Minalloc = Cparhdr + sizeof(UInt16),
            Maxalloc = Minalloc + sizeof(UInt16),
            Ss = Maxalloc + sizeof(UInt16),
            Sp = Ss + sizeof(UInt16),
            Csum = Sp + sizeof(UInt16),
            Ip = Csum + sizeof(UInt16),
            Cs = Ip + sizeof(UInt16),
            Lfarlc = Cs + sizeof(UInt16),
            Ovno = Lfarlc + sizeof(UInt16),
            Res = Ovno + sizeof(UInt16),
            Oemid = Res + sizeof(UInt16) * 4,
            Oeminfo = Oemid + sizeof(UInt16),
            Res2 = Oeminfo + sizeof(UInt16),
            Lfanew = Res2 + sizeof(UInt16) * 10,
            DosHeaderSize = Lfanew + sizeof(UInt16)
        }
        public UInt16 Magic
        {
            get
            {
                return ToUInt16(Offset.Magic);
            }
            set
            {
                SetUInt16(value, Offset.Magic);
            }
        }
        public UInt16 Cblp
        {
            get
            {
                return ToUInt16(Offset.Cblp);
            }
            set
            {
                SetUInt16(value, Offset.Cblp);
            }
        }
        public UInt16 Cp
        {
            get
            {
                return ToUInt16(Offset.Cp);
            }
            set
            {
                SetUInt16(value, Offset.Cp);
            }
        }
        public UInt16 Crlc
        {
            get
            {
                return ToUInt16(Offset.Crlc);
            }
            set
            {
                SetUInt16(value, Offset.Crlc);
            }
        }
        public UInt16 Cparhdr
        {
            get
            {
                return ToUInt16(Offset.Cparhdr);
            }
            set
            {
                SetUInt16(value, Offset.Cparhdr);
            }
        }
        public UInt16 Minalloc
        {
            get
            {
                return ToUInt16(Offset.Minalloc);
            }
            set
            {
                SetUInt16(value, Offset.Minalloc);
            }
        }
        public UInt16 Maxalloc
        {
            get
            {
                return ToUInt16(Offset.Maxalloc);
            }
            set
            {
                SetUInt16(value, Offset.Maxalloc);
            }
        }
        public UInt16 Ss
        {
            get
            {
                return ToUInt16(Offset.Ss);
            }
            set
            {
                SetUInt16(value, Offset.Ss);
            }
        }
        public UInt16 Sp
        {
            get
            {
                return ToUInt16(Offset.Sp);
            }
            set
            {
                SetUInt16(value, Offset.Sp);
            }
        }
        public UInt16 Csum
        {
            get
            {
                return ToUInt16(Offset.Csum);
            }
            set
            {
                SetUInt16(value, Offset.Csum);
            }
        }
        public UInt16 Ip
        {
            get
            {
                return ToUInt16(Offset.Ip);
            }
            set
            {
                SetUInt16(value, Offset.Ip);
            }
        }
        public UInt16 Cs
        {
            get
            {
                return ToUInt16(Offset.Cs);
            }
            set
            {
                SetUInt16(value, Offset.Cs);
            }
        }
        public UInt16 Lfarlc
        {
            get
            {
                return ToUInt16(Offset.Lfarlc);
            }
            set
            {
                SetUInt16(value, Offset.Lfarlc);
            }
        }
        public UInt16 Ovno
        {
            get
            {
                return ToUInt16(Offset.Ovno);
            }
            set
            {
                SetUInt16(value, Offset.Ovno);
            }
        }
        public UInt16[] Res
        {
            get
            {
                List<UInt16> result = new List<UInt16>();
                for (int i = (int)Offset.Res; i < (int)Offset.Oemid; i += sizeof(UInt16))
                {
                    result.Add(base.ToUInt16(i));
                }
                return result.ToArray();
            }
            set
            {
                for (int j = 0, i = (int)Offset.Res; i < (int)Offset.Oemid; j++, i += sizeof(UInt16))
                {
                    base.SetUInt16(value[j], i);
                }
            }
        }
        public UInt16 Oemid
        {
            get
            {
                return ToUInt16(Offset.Oemid);
            }
            set
            {
                SetUInt16(value, Offset.Oemid);
            }
        }
        public UInt16 Oeminfo
        {
            get
            {
                return ToUInt16(Offset.Oeminfo);
            }
            set
            {
                SetUInt16(value, Offset.Oeminfo);
            }
        }
        public UInt16[] Res2
        {
            get
            {
                List<UInt16> result = new List<UInt16>();
                for (int i = (int)Offset.Res2; i < (int)Offset.Lfanew; i += sizeof(UInt16))
                {
                    result.Add(base.ToUInt16(i));
                }
                return result.ToArray();
            }
            set
            {
                for (int j = 0, i = (int)Offset.Res2; i < (int)Offset.Lfanew; j++, i += sizeof(UInt16))
                {
                    base.SetUInt16(value[j], i);
                }
            }
        }
        public UInt16 Lfanew
        {
            get
            {
                return ToUInt16(Offset.Lfanew);
            }
            set
            {
                SetUInt16(value, Offset.Lfanew);
            }
        }
        public DosHeader(Byte[] buffer, int offset) : base(buffer, offset)
        {
        }
        public override int RawSize
        {
            get
            {
                return (int)Offset.DosHeaderSize;
            }
        }
    }
}
