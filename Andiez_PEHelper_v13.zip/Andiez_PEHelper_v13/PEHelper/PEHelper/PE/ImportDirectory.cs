﻿using System;
using System.Collections.Generic;
using PEHelper.Pe;

namespace PEHelper.PE
{
    public struct __ILT_ENTRY_64
    {
        public UInt32 ordinal;
        public UInt32 hintName;
        public UInt32 OrdinalNameFlag;
    };

    public class ImportDirectory : SafeStruct
    {
        public List<ImportFunction> ImportFuncList { get; set; }
        public List<ImageThunkData> ImageThunkDataList { get; set; }
        private enum Offset : int
        {
            OriginalFirstThunk = 0,
            TimeDateStamp = OriginalFirstThunk + sizeof(UInt32),
            ForwarderChain = TimeDateStamp + sizeof(UInt32),
            NameRVA = ForwarderChain + sizeof(UInt32),
            FirstThunk = NameRVA + sizeof(UInt32),
            ImportDirectorySize = FirstThunk + sizeof(UInt32),
        }

        public int DirectoryCount;
        public UInt32 OriginalFirstThunk
        {
            get
            {
                return ToUInt32(Offset.OriginalFirstThunk);
            }
            set
            {
                SetUInt32(value, Offset.OriginalFirstThunk);
            }
        }
        public UInt32 TimeDateStamp
        {
            get
            {
                return ToUInt32(Offset.TimeDateStamp);
            }
            set
            {
                SetUInt32(value, Offset.TimeDateStamp);
            }
        }
        public UInt32 ForwarderChain
        {
            get
            {
                return ToUInt32(Offset.ForwarderChain);
            }
            set
            {
                SetUInt32(value, Offset.ForwarderChain);
            }
        }
        public UInt32 NameRVA
        {
            get
            {
                return ToUInt32(Offset.NameRVA);
            }
            set
            {
                SetUInt32(value, Offset.NameRVA);
            }
        }
        public UInt32 FirstThunk
        {
            get
            {
                return ToUInt32(Offset.FirstThunk);
            }
            set
            {
                SetUInt32(value, Offset.FirstThunk);
            }
        }
        public ImportDirectory(Byte[] buffer, int offset = 0) : base(buffer, offset)
        {
            ImportFuncList = new List<ImportFunction>();
            ImageThunkDataList = new List<ImageThunkData>();
        }
        public override int RawSize
        {
            get
            {
                return (int)Offset.ImportDirectorySize;
            }
        }
        public int offset
        {
            get
            {
                return _offset;
            }
            set
            {
                value = _offset;
            }
        }
    }
}
