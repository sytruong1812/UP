﻿using System;

namespace PEHelper.Pe
{
    public class OptionalHeader : SafeStruct
    {
        private enum eMagic : UInt16
        {
            PE32 = 0x010b,
            PE64 = 0x020b
        }
        private enum Offset : int
        {
            Magic = 0,
            MajorLinkerVersion = Magic + sizeof(UInt16),
            MinorLinkerVersion = MajorLinkerVersion + sizeof(Byte),
            SizeOfCode = MinorLinkerVersion + sizeof(Byte),
            SizeOfInitializedData = SizeOfCode + sizeof(UInt32),
            SizeOfUninitializedData = SizeOfInitializedData + sizeof(UInt32),
            AddressOfEntryPoint = SizeOfUninitializedData + sizeof(UInt32),
            BaseOfCode = AddressOfEntryPoint + sizeof(UInt32)
        }
        public UInt16 Magic
        {
            get
            {
                return ToUInt16(Offset.Magic);
            }
            set
            {
                SetUInt16(value, Offset.Magic);
            }
        }
        public byte MajorLinkerVersion
        {
            get
            {
                return ToByte(Offset.MajorLinkerVersion);
            }
            set
            {
                SetByte(value, Offset.MajorLinkerVersion);
            }
        }
        public byte MinorLinkerVersion
        {
            get
            {
                return ToByte(Offset.MinorLinkerVersion);
            }
            set
            {
                SetByte(value, Offset.MinorLinkerVersion);
            }
        }
        public UInt32 SizeOfCode
        {
            get
            {
                return ToUInt32(Offset.SizeOfCode);
            }
            set
            {
                SetUInt32(value, Offset.SizeOfCode);
            }
        }
        public UInt32 SizeOfInitializedData
        {
            get
            {
                return ToUInt32(Offset.SizeOfInitializedData);
            }
            set
            {
                SetUInt32(value, Offset.SizeOfInitializedData);
            }
        }
        public UInt32 SizeOfUninitializedData
        {
            get
            {
                return ToUInt32(Offset.SizeOfUninitializedData);
            }
            set
            {
                SetUInt32(value, Offset.SizeOfUninitializedData);
            }
        }
        public UInt32 AddressOfEntryPoint
        {
            get
            {
                return ToUInt32(Offset.AddressOfEntryPoint);
            }
            set
            {
                SetUInt32(value, Offset.AddressOfEntryPoint);
            }
        }
        public UInt32 BaseOfCode
        {
            get
            {
                return ToUInt32(Offset.BaseOfCode);
            }
            set
            {
                SetUInt32(value, Offset.BaseOfCode);
            }
        }
        private enum Offset32 : int
        {
            BaseOfData = Offset.BaseOfCode + sizeof(UInt32),
            ImageBase = BaseOfData + sizeof(UInt32),
            SectionAlignment = ImageBase + sizeof(UInt32),
            FileAlignment = SectionAlignment + sizeof(UInt32),
            MajorOperatingSystemVersion = FileAlignment + sizeof(UInt32),
            MinorOperatingSystemVersion = MajorOperatingSystemVersion + sizeof(UInt16),
            MajorImageVersion = MinorOperatingSystemVersion + sizeof(UInt16),
            MinorImageVersion = MajorImageVersion + sizeof(UInt16),
            MajorSubsystemVersion = MinorImageVersion + sizeof(UInt16),
            MinorSubsystemVersion = MajorSubsystemVersion + sizeof(UInt16),
            Win32VersionValue = MinorSubsystemVersion + sizeof(UInt16),
            SizeOfImage = Win32VersionValue + sizeof(UInt32),
            SizeOfHeaders = SizeOfImage + sizeof(UInt32),
            CheckSum = SizeOfHeaders + sizeof(UInt32),
            Subsystem = CheckSum + sizeof(UInt32),
            DllCharacteristics = Subsystem + sizeof(UInt16),
            SizeOfStackReserve = DllCharacteristics + sizeof(UInt16),
            SizeOfStackCommit = SizeOfStackReserve + sizeof(UInt32),
            SizeOfHeapReserve = SizeOfStackCommit + sizeof(UInt32),
            SizeOfHeapCommit = SizeOfHeapReserve + sizeof(UInt32),
            LoaderFlags = SizeOfHeapCommit + sizeof(UInt32),
            NumberOfRvaAndSizes = LoaderFlags + sizeof(UInt32),
            DataDirectory = NumberOfRvaAndSizes + sizeof(UInt32),
            OptionalHeaderSize = DataDirectory + sizeof(UInt32) * 2 * 16
        }
        private enum Offset64 : int
        {
            ImageBase = Offset.BaseOfCode + sizeof(UInt32),
            SectionAlignment = ImageBase + sizeof(UInt64),
            FileAlignment = SectionAlignment + sizeof(UInt32),
            MajorOperatingSystemVersion = FileAlignment + sizeof(UInt32),
            MinorOperatingSystemVersion = MajorOperatingSystemVersion + sizeof(UInt16),
            MajorImageVersion = MinorOperatingSystemVersion + sizeof(UInt16),
            MinorImageVersion = MajorImageVersion + sizeof(UInt16),
            MajorSubsystemVersion = MinorImageVersion + sizeof(UInt16),
            MinorSubsystemVersion = MajorSubsystemVersion + sizeof(UInt16),
            Win32VersionValue = MinorSubsystemVersion + sizeof(UInt16),
            SizeOfImage = Win32VersionValue + sizeof(UInt32),
            SizeOfHeaders = SizeOfImage + sizeof(UInt32),
            CheckSum = SizeOfHeaders + sizeof(UInt32),
            Subsystem = CheckSum + sizeof(UInt32),
            DllCharacteristics = Subsystem + sizeof(UInt16),
            SizeOfStackReserve = DllCharacteristics + sizeof(UInt16),
            SizeOfStackCommit = SizeOfStackReserve + sizeof(UInt64),
            SizeOfHeapReserve = SizeOfStackCommit + sizeof(UInt64),
            SizeOfHeapCommit = SizeOfHeapReserve + sizeof(UInt64),
            LoaderFlags = SizeOfHeapCommit + sizeof(UInt64),
            NumberOfRvaAndSizes = LoaderFlags + sizeof(UInt32),
            DataDirectory = NumberOfRvaAndSizes + sizeof(UInt32),
            OptionalHeaderSize = DataDirectory + sizeof(UInt32) * 2 * 16
        }
        public UInt32 BaseOfData
        {
            get
            {
                if (!Is86)
                {
                    return 0;
                }
                return ToUInt32(Offset32.BaseOfData);
            }
            set
            {
                if (Is86)
                {
                    SetUInt32(value, Offset32.BaseOfData);
                }
            }
        }
        public UInt64 ImageBase
        {
            get
            {
                if (Is86)
                {
                    return ToUInt32(Offset32.ImageBase);
                }
                return ToUInt64(Offset64.ImageBase);
            }
            set
            {
                if (Is86)
                {
                    SetUInt32(Convert.ToUInt32(value), Offset32.ImageBase);
                }
                else
                {
                    SetUInt64(value, Offset64.ImageBase);
                }
            }
        }
        public UInt32 SectionAlignment
        {
            get
            {
                int offset = Is86 ? (int)Offset32.SectionAlignment : (int)Offset64.SectionAlignment;
                return ToUInt32(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.SectionAlignment : (int)Offset64.SectionAlignment;
                SetUInt32(value, offset);
            }
        }
        public UInt32 FileAlignment
        {
            get
            {
                int offset = Is86 ? (int)Offset32.FileAlignment : (int)Offset64.FileAlignment;
                return ToUInt32(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.FileAlignment : (int)Offset64.FileAlignment;
                SetUInt32(value, offset);
            }
        }
        public UInt16 MajorOperatingSystemVersion
        {
            get
            {
                int offset = Is86 ? (int)Offset32.MajorOperatingSystemVersion : (int)Offset64.MajorOperatingSystemVersion;
                return ToUInt16(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.MajorOperatingSystemVersion : (int)Offset64.MajorOperatingSystemVersion;
                SetUInt16(value, offset);
            }
        }
        public UInt16 MinorOperatingSystemVersion
        {
            get
            {
                int offset = Is86 ? (int)Offset32.MinorOperatingSystemVersion : (int)Offset64.MinorOperatingSystemVersion;
                return ToUInt16(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.MinorOperatingSystemVersion : (int)Offset64.MinorOperatingSystemVersion;
                SetUInt16(value, offset);
            }
        }
        public UInt16 MajorImageVersion
        {
            get
            {
                int offset = Is86 ? (int)Offset32.MajorImageVersion : (int)Offset64.MajorImageVersion;
                return ToUInt16(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.MajorImageVersion : (int)Offset64.MajorImageVersion;
                SetUInt16(value, offset);
            }
        }
        public UInt16 MinorImageVersion
        {
            get
            {
                int offset = Is86 ? (int)Offset32.MinorImageVersion : (int)Offset64.MinorImageVersion;
                return ToUInt16(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.MinorImageVersion : (int)Offset64.MinorImageVersion;
                SetUInt16(value, offset);
            }
        }
        public UInt16 MajorSubsystemVersion
        {
            get
            {
                int offset = Is86 ? (int)Offset32.MajorSubsystemVersion : (int)Offset64.MajorSubsystemVersion;
                return ToUInt16(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.MajorSubsystemVersion : (int)Offset64.MajorSubsystemVersion;
                SetUInt16(value, offset);
            }
        }
        public UInt16 MinorSubsystemVersion
        {
            get
            {
                int offset = Is86 ? (int)Offset32.MinorSubsystemVersion : (int)Offset64.MinorSubsystemVersion;
                return ToUInt16(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.MinorSubsystemVersion : (int)Offset64.MinorSubsystemVersion;
                SetUInt16(value, offset);
            }
        }
        public UInt32 Win32VersionValue
        {
            get
            {
                int offset = Is86 ? (int)Offset32.Win32VersionValue : (int)Offset64.Win32VersionValue;
                return ToUInt32(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.Win32VersionValue : (int)Offset64.Win32VersionValue;
                SetUInt32(value, offset);
            }
        }
        public UInt32 SizeOfImage
        {
            get
            {
                int offset = Is86 ? (int)Offset32.SizeOfImage : (int)Offset64.SizeOfImage;
                return ToUInt32(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.SizeOfImage : (int)Offset64.SizeOfImage;
                SetUInt32(value, offset);
            }
        }
        public UInt32 SizeOfHeaders
        {
            get
            {
                int offset = Is86 ? (int)Offset32.SizeOfHeaders : (int)Offset64.SizeOfHeaders;
                return ToUInt32(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.SizeOfHeaders : (int)Offset64.SizeOfHeaders;
                SetUInt32(value, offset);
            }
        }
        public UInt32 CheckSum
        {
            get
            {
                int offset = Is86 ? (int)Offset32.CheckSum : (int)Offset64.CheckSum;
                return ToUInt32(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.CheckSum : (int)Offset64.CheckSum;
                SetUInt32(value, offset);
            }
        }
        public UInt16 Subsystem
        {
            get
            {
                int offset = Is86 ? (int)Offset32.Subsystem : (int)Offset64.Subsystem;
                return ToUInt16(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.Subsystem : (int)Offset64.Subsystem;
                SetUInt16(value, offset);
            }
        }
        public UInt16 DllCharacteristics
        {
            get
            {
                int offset = Is86 ? (int)Offset32.DllCharacteristics : (int)Offset64.DllCharacteristics;
                return ToUInt16(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.DllCharacteristics : (int)Offset64.DllCharacteristics;
                SetUInt16(value, offset);
            }
        }
        public UInt64 SizeOfStackReserve
        {
            get
            {
                if (Is86)
                {
                    return ToUInt64(Offset32.SizeOfStackReserve);
                }
                return ToUInt32(Offset64.SizeOfStackReserve);
            }
            set
            {
                if (Is86)
                {
                    SetUInt32(Convert.ToUInt32(value), Offset32.SizeOfStackReserve);
                }
                else
                {
                    SetUInt64(value, Offset64.SizeOfStackReserve);
                }
            }
        }
        public UInt64 SizeOfStackCommit
        {
            get
            {
                if (Is86)
                {
                    return ToUInt64(Offset32.SizeOfStackCommit);
                }
                return ToUInt32(Offset64.SizeOfStackCommit);
            }
            set
            {
                if (Is86)
                {
                    SetUInt32(Convert.ToUInt32(value), Offset32.SizeOfStackCommit);
                }
                else
                {
                    SetUInt64(value, Offset64.SizeOfStackCommit);
                }
            }
        }
        public UInt64 SizeOfHeapReserve
        {
            get
            {
                if (Is86)
                {
                    return ToUInt64(Offset32.SizeOfHeapReserve);
                }
                return ToUInt32(Offset64.SizeOfHeapReserve);
            }
            set
            {
                if (Is86)
                {
                    SetUInt32(Convert.ToUInt32(value), Offset32.SizeOfHeapReserve);
                }
                else
                {
                    SetUInt64(value, Offset64.SizeOfHeapReserve);
                }
            }
        }
        public UInt64 SizeOfHeapCommit
        {
            get
            {
                if (Is86)
                {
                    return ToUInt64(Offset32.SizeOfHeapCommit);
                }
                return ToUInt32(Offset64.SizeOfHeapCommit);
            }
            set
            {
                if (Is86)
                {
                    SetUInt32(Convert.ToUInt32(value), Offset32.SizeOfHeapCommit);
                }
                else
                {
                    SetUInt64(value, Offset64.SizeOfHeapCommit);
                }
            }
        }
        public UInt32 LoaderFlags
        {
            get
            {
                int offset = Is86 ? (int)Offset32.LoaderFlags : (int)Offset64.LoaderFlags;
                return ToUInt32(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.LoaderFlags : (int)Offset64.LoaderFlags;
                SetUInt32(value, offset);
            }
        }
        public UInt32 NumberOfRvaAndSizes
        {
            get
            {
                int offset = Is86 ? (int)Offset32.NumberOfRvaAndSizes : (int)Offset64.NumberOfRvaAndSizes;
                return ToUInt32(offset);
            }
            set
            {
                int offset = Is86 ? (int)Offset32.NumberOfRvaAndSizes : (int)Offset64.NumberOfRvaAndSizes;
                SetUInt32(value, offset);
            }
        }
        public DataDirectory[] DataDirectories { get; private set; }
        public OptionalHeader(Byte[] buffer, int offset = 0) : base(buffer, offset)
        {
            DataDirectories = new DataDirectory[16];
            offset += Is86 ? (int)Offset32.DataDirectory : (int)Offset64.DataDirectory;
            for (int i = 0; i < DataDirectories.Length; i++)
            {
                DataDirectories[i] = new DataDirectory(buffer, offset);
                offset += DataDirectories[i].RawSize;
            }
        }
        public override int RawSize
        {
            get
            {
                return Is86 ? (int)Offset32.OptionalHeaderSize : (int)Offset64.OptionalHeaderSize;
            }
        }
        public bool Is86
        {
            get { return Magic == (UInt16)eMagic.PE32; }
        }
    }
}
